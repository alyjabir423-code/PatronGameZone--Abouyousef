import json, ipaddress, math
from urllib.parse import urlsplit
from firebase_transport import validate_database_url
from room_identity import OWNER_UID, RELAY_UID, runtime_config


def validate_import(config_text, deadlines_text, key_text=None):
    if key_text is not None:
        # Existing APK bridge reuses this entry point for a local key update.
        current=json.loads(config_text)
        poste=str(int(deadlines_text))
        if not isinstance(key_text,str) or len(key_text.encode())!=16 or poste not in current['postes']:
            raise ValueError('Poste ou clé locale invalide')
        current['devices'][current['postes'][poste]]['key']=key_text
        return validate_import(json.dumps(current),'{}')
    c=json.loads(config_text); state=json.loads(deadlines_text)
    c=runtime_config(c)
    u=urlsplit(c['url'])
    firebase=c.get('transport')=='firebase'
    if not firebase:
        raise ValueError('Cette application YOUSSEF exige une configuration Firebase YOUSSEF')
    if firebase:
        validate_database_url(c['url'])
        if not ((isinstance(c.get('idToken'),str) and c['idToken'].strip()) or (isinstance(c.get('refreshToken'),str) and c['refreshToken'].strip())):
            raise ValueError('Authentification Firebase requise')
        if c.get('room')!='abou-youssef' or c.get('protocol')!='pilotage_v1' or u.hostname!='gamzone-youssef-7e8ae-default-rtdb.firebaseio.com':
            raise ValueError('La configuration doit correspondre à YOUSSEF / pilotage_v1')
        for field in ('refreshToken','apiKey','relayUid','ownerUid'):
            if not isinstance(c.get(field),str) or not c[field].strip():
                raise ValueError('Champ Firebase requis : '+field)
        if c['relayUid']!=RELAY_UID or c['ownerUid']!=OWNER_UID:
            raise ValueError('Comptes Firebase différents de cette salle')
    if not isinstance(c.get('devices'),dict) or not c['devices']:
        raise ValueError('Aucune prise configurée')
    postes=c.get('postes')
    if not isinstance(postes,dict) or len(postes)!=len(c['devices']) or set(postes.values())!=set(c['devices']) or len(set(postes.values()))!=len(postes):
        raise ValueError('Correspondance postes/prises invalide')
    if any(not isinstance(k,str) or not k.isascii() or not k.isdigit() or int(k)<1 or str(int(k))!=k for k in postes):
        raise ValueError('Numéro de poste invalide')
    if firebase and (not isinstance(c.get('room'),str) or not c['room'] or len(c['room'])>64 or not all(ch.isalnum() or ch in '-_' for ch in c['room'])):
        raise ValueError('Salle Firebase requise et invalide')
    devices={}
    for did,row in c['devices'].items():
        ip=ipaddress.ip_address(row['ip'])
        if ip.version!=4 or not ip.is_private or ip.is_loopback or ip.is_unspecified or ip.is_multicast:
            raise ValueError('Adresse locale invalide')
        if not isinstance(row['key'],str) or len(row['key'].encode())!=16 or float(row['version']) not in (3.3,3.4,3.5):
            raise ValueError('Clé ou protocole invalide')
        devices[did]={'ip':str(ip),'key':row['key'],'version':float(row['version'])}
    if not isinstance(state,dict) or set(state)-set(devices):raise ValueError('Échéances invalides')
    for row in state.values():
        if not isinstance(row,dict):raise ValueError('Échéance invalide')
        for k in ('deadline','offset','armedSeconds'):
            if k in row and (type(row[k]) not in (int,float) or not math.isfinite(row[k])):raise ValueError('Échéance invalide')
        if row.get('deadline',0)<0 or not 0<=row.get('armedSeconds',0)<=86400:raise ValueError('Échéance invalide')
    result={'url':c['url'],'agent':c.get('agent',''),'devices':devices,'postes':postes,'room':c.get('room','abou-youssef')}
    if firebase:
        result.update(transport='firebase',idToken=c.get('idToken',''),protocol='pilotage_v1',
            refreshToken=c['refreshToken'],apiKey=c['apiKey'],relayUid=c['relayUid'],ownerUid=c['ownerUid'])
        migration=c.get('migrationState',{'sessions':{},'processed':{},'results':{}})
        if not isinstance(migration,dict) or not isinstance(migration.get('sessions',{}),dict) or not isinstance(migration.get('processed',{}),dict) or not isinstance(migration.get('results',{}),dict):
            raise ValueError('État de migration invalide')
        from pilotage_core import validate_session
        for poste,row in migration.get('sessions',{}).items():
            if poste not in postes:raise ValueError('Poste de migration inconnu')
            validate_session(row)
        for cid,stamp in migration.get('processed',{}).items():
            if not isinstance(cid,str) or not 16<=len(cid)<=80 or type(stamp) not in (int,float) or not math.isfinite(stamp) or stamp<0:
                raise ValueError('Journal de migration invalide')
        for poste,row in migration.get('results',{}).items():
            if poste not in postes or not isinstance(row,dict):raise ValueError('Confirmation de migration invalide')
        result['migrationState']=migration
    else:result['secret']=c['secret']
    return json.dumps(result)
