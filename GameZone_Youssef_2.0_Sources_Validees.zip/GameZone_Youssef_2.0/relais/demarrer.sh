#!/data/data/com.termux/files/usr/bin/bash
set -eu
cd -- "$(dirname -- "$0")"
termux-wake-lock
exec 9>superviseur-v2.lock
flock -n 9 || { echo 'Superviseur Youssef déjà lancé.'; exit 0; }
mkdir -p journaux
chmod 700 journaux
trap 'if [ -n "${relay_pid:-}" ]; then kill "$relay_pid" 2>/dev/null || true; fi; exit' INT TERM
while true; do
 python -u relais_firebase.py demarrer >>journaux/relais-v2.log 2>&1 &
 relay_pid=$!
 wait "$relay_pid" || true
 if [ "$(wc -c <journaux/relais-v2.log)" -gt 524288 ]; then mv -f journaux/relais-v2.log journaux/relais-v2-precedent.log; fi
 sleep 5
done
