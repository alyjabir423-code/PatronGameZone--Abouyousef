#!/usr/bin/env python3
"""Termux entry point. Seven Youssef plugs only. No inbound port or Cloudflare."""
import argparse
import fcntl
import getpass
import json
import signal
import sys
import threading
import time
import uuid
from pathlib import Path
from room_identity import DB_URL, OWNER_UID, RELAY_UID, API_KEY, IDS, runtime_config
from relay_core import load, save

BASE = Path(__file__).resolve().parent

def build_config(directory=BASE):
    directory = Path(directory)
    raw = load(directory/'devices.json', [])
    if not isinstance(raw, list) or len(raw) != 7 or {x.get('poste'): x.get('id') for x in raw} != IDS:
        raise ValueError('devices.json doit contenir les sept prises Abou Youssef, sans doublon')
    creds = load(directory/'prive_firebase.json', {})
    if not creds.get('refreshToken'):
        raise ValueError('Connexion du relais requise : python relais_firebase.py configurer')
    previous = load(directory/'identite_relais.json', {})
    agent = previous.get('agent') or str(uuid.uuid4())
    if not previous.get('agent'):
        save(directory/'identite_relais.json', {'agent': agent})
    config = {'url': DB_URL, 'room': 'abou-youssef', 'protocol': 'pilotage_v1', 'transport': 'firebase',
              'ownerUid': OWNER_UID, 'relayUid': RELAY_UID, 'apiKey': API_KEY,
              'refreshToken': creds['refreshToken'], 'agent': agent,
              'postes': {str(n): did for n, did in IDS.items()},
              'devices': {x['id']: {'ip': x['ip'], 'key': x['key'], 'version': x.get('version', 3.5)} for x in raw}}
    legacy = load(directory/'etat_firebase.json', {})
    if not (directory/'pilotage_state.json').exists() and legacy:
        config['migrationState'] = {k: legacy.get(k, {}) for k in ('sessions', 'processed', 'results')}
    from engine import validate_import
    return json.loads(validate_import(json.dumps(config), '{}'))

class Bridge:
    def __init__(self):
        self.stopped = threading.Event()
        self.last = ''
        self.last_snapshot = 0
    def shouldStop(self): return self.stopped.is_set()
    def shouldCheck(self): return False
    def report(self, message):
        if message != self.last:
            print(message, flush=True)
            self.last = message
    def snapshot(self, value):
        # No keys, tokens or raw vendor responses in logs.
        if time.monotonic()-self.last_snapshot < 30:
            return
        self.last_snapshot = time.monotonic()
        rows = json.loads(value)
        for row in rows:
            print('Poste', row['poste'], row['etat'], '— minuteur prise :', row['secondes'], 's', flush=True)
    def persist_refresh(self, token):
        creds = load(BASE/'prive_firebase.json', {})
        creds['refreshToken'] = token
        save(BASE/'prive_firebase.json', creds)

def configure():
    import requests
    email = input('E-mail du compte relais Youssef : ').strip()
    password = getpass.getpass('Mot de passe (masqué) : ')
    r = requests.post('https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword',
        params={'key': API_KEY}, json={'email': email, 'password': password, 'returnSecureToken': True}, timeout=(3, 12))
    data = r.json()
    if r.status_code != 200 or data.get('localId') != RELAY_UID:
        raise ValueError('Le compte doit être le compte relais Abou Youssef autorisé')
    save(BASE/'prive_firebase.json', {'refreshToken': data['refreshToken']})
    print('Compte relais Youssef enregistré. Aucun identifiant privé affiché.')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['configurer', 'verifier', 'demarrer'])
    args = parser.parse_args()
    if args.action == 'configurer':
        configure(); return
    lock = (BASE/'relais-v2.lock').open('w')
    try: fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError: raise ValueError('Un relais Youssef v2 est déjà lancé sur ce téléphone')
    config = build_config()
    if args.action == 'verifier':
        import tinytuya
        for n, did in IDS.items():
            row = config['devices'][did]
            plug = tinytuya.OutletDevice(did, row['ip'], row['key'], version=row['version'])
            plug.set_socketTimeout(2); plug.set_socketRetryLimit(1)
            try:
                dps = plug.status().get('dps', {})
                ok = type(dps.get('1')) is bool and type(dps.get('9')) is int
                print('Poste', n, ':', 'confirmé' if ok else 'NON confirmé',
                      '; état :', dps.get('1'), '; minuteur :', dps.get('9'), flush=True)
            except Exception:
                print('Poste', n, ': NON confirmé', flush=True)
            finally: plug.close()
        return
    import requests
    from pilotage_runner import PilotageRunner
    bridge = Bridge()
    def stop(*_): bridge.stopped.set()
    signal.signal(signal.SIGTERM, stop); signal.signal(signal.SIGINT, stop)
    session = requests.Session()
    runner = PilotageRunner(BASE, config, bridge, session)
    try: runner.run()
    finally: session.close()

if __name__ == '__main__':
    try: main()
    except (ValueError, OSError, KeyError, json.JSONDecodeError) as exc:
        print('Configuration Youssef invalide. Vérifier les fichiers privés sur le téléphone.', file=sys.stderr)
        sys.exit(1)
