#!/data/data/com.termux/files/usr/bin/bash
set -eu
source_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
target_dir="$HOME/GameZone_Abou_Youssef_Firebase"
[ -f "$target_dir/devices.json" ] || { echo 'Dossier Youssef existant introuvable. Ne rien installer dans CP1.'; exit 1; }
python - "$target_dir/devices.json" "$source_dir" <<'PY'
import json,sys
sys.path.insert(0,sys.argv[2])
from room_identity import IDS
data=json.load(open(sys.argv[1]))
assert isinstance(data,list) and len(data)==7 and {d['poste']:d['id'] for d in data}==IDS, 'Les prises ne sont pas les sept prises Youssef : installation refusée'
PY
# Do not replace a running engine or stop an unrelated room.
python - "$target_dir" <<'PY'
import os,sys
from pathlib import Path
target=Path(sys.argv[1]).resolve()
for proc in Path('/proc').glob('[0-9]*'):
    if proc.name==str(os.getpid()):continue
    try:
        cmd=(proc/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
        cwd=(proc/'cwd').resolve()
        if cwd==target and ('relais_firebase.py demarrer' in cmd or 'bash demarrer.sh' in cmd):
            raise SystemExit('Arrêter le relais Youssef et son superviseur avant la mise à jour. Aucun autre relais ne sera arrêté automatiquement.')
    except (PermissionError,FileNotFoundError,ProcessLookupError):pass
PY
backup_dir="$target_dir/sauvegarde-$(date +%Y%m%d-%H%M%S)"
mkdir -m 700 "$backup_dir"
for file in "$target_dir"/*.py "$target_dir"/*.sh "$target_dir"/*.json; do
 [ -f "$file" ] || continue
 cp -p "$file" "$backup_dir/"
done
chmod -R go-rwx "$backup_dir"
for file in "$source_dir"/*.py "$source_dir/demarrer.sh" "$source_dir/requirements.txt"; do cp "$file" "$target_dir/"; done
python -m pip install -r "$target_dir/requirements.txt"
python -m compileall -q "$target_dir"
chmod 600 "$target_dir"/*.json
printf 'Mise à jour Youssef installée. Sauvegarde locale : %s\n' "$backup_dir"
echo 'Ne démarre pas deux relais : Termux et APK ne doivent pas piloter la même salle ensemble.'
echo 'Contrôle en lecture seule :'
printf 'cd "%s"\npython relais_firebase.py verifier\n' "$target_dir"
