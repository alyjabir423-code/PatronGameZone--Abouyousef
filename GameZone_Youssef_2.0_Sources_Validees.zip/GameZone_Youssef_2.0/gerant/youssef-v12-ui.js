/* YOUSSEF 1.2 — current shift, saved credit and native countdown reconciliation. */
(function(w){'use strict';
const patron=typeof ownerOpenStart==='function',busy=new Set();
const posts=()=>patron?(DB.get('postes')||[]):postes;
const active=(p,i)=>patron?(activeForPoste(p,i)||{}):p;
const toast=text=>showToast(text);
const format=sec=>{sec=Math.max(0,Math.floor(Number(sec)||0));return Math.floor(sec/60)+' min '+String(sec%60).padStart(2,'0')+' s';};
function refresh(){DB._cache=YOUSSEFRelay.syncPhysicalRoot(DB._cache);if(patron){renderControl();ownerRenderDashboard();}else{refreshFromRemote();updateStats();}drawBanks();}
function card(index){const list=YOUSSEFRelay.entries(posts()),position=list.findIndex(x=>x.i===index);return document.querySelectorAll(patron?'#control-postes > .ctl-card:not(.bonus-master):not(.gym-card)':'#postes-grid > .pc')[position];}
async function run(index,fn){if(busy.has(index))return;busy.add(index);card(index)?.querySelectorAll('button').forEach(b=>b.disabled=true);try{const tx=await fn();if(tx?.snapshot)DB._cache=tx.snapshot.val()||DB._cache;refresh();}catch(e){toast(e.message||'Opération non confirmée');}finally{busy.delete(index);card(index)?.querySelectorAll('button').forEach(b=>b.disabled=false);}}
w.youssefSaveTime=index=>run(index,async()=>{const p=posts()[index];if(!p)return;toast('Sauvegarde — confirmation de la prise…');const result=await YOUSSEFRelay.saveTime(p);toast('Temps sauvegardé jusqu’à 8 h. Le poste est libre.');return result;});
w.youssefRestoreTime=(bankId,index)=>run(Number(index),async()=>{const p=posts()[Number(index)];if(!p)return;toast('Restauration — confirmation de la prise…');const result=await YOUSSEFRelay.restoreTime(bankId,p);toast('Temps restauré. Aucune nouvelle recette comptée.');return result;});
// Show acceptance immediately; keep physical confirmation and accounting unchanged.
for(const [name,label]of patron?[['ownerPause','Pause'],['ownerResume','Reprise']]:[['pausePoste','Pause'],['reprendrePoste','Reprise']]){
 const original=w[name];if(typeof original!=='function')continue;
 w[name]=function(index,...args){if(busy.has(index))return;toast(label+' en cours — confirmation de la prise…');return run(index,()=>original(index,...args));};
}
w.addEventListener('youssef-physical-update',()=>{if(typeof DB!=='undefined'&&DB._cache)refresh();});
function drawControls(){for(const {p,i}of YOUSSEFRelay.entries(posts())){const c=card(i);if(!c||c.querySelector('.youssef-bank-actions'))continue;const a=active(p,i);if(!a.actif)continue;const area=document.createElement('div');area.className='youssef-bank-actions';const b=document.createElement('button');b.className=patron?'ctl-btn ctl-plus':'pb pb-on';b.textContent='💾 SAUVEGARDER LE TEMPS';b.style.cssText='width:100%;margin-top:8px;padding:10px';b.onclick=()=>w.youssefSaveTime(i);b.disabled=busy.has(i);area.append(b);if(!patron){const stop=document.createElement('button');stop.className='pc-btn btn-cancel';stop.textContent='ANNULER LE TEMPS';stop.style.cssText='width:100%;margin-top:8px;padding:10px';stop.onclick=()=>w.youssefCancelTime(i);stop.disabled=busy.has(i);area.append(stop);}c.append(area);}}
function drawBanks(){drawControls();const grid=document.getElementById(patron?'control-postes':'postes-grid');if(!grid)return;let box=document.getElementById('youssef-saved-times');if(!box){box=document.createElement('section');box.id='youssef-saved-times';box.style.cssText='grid-column:1/-1;padding:12px;background:#21172e;border:1px solid #735b9b;border-radius:12px;margin-top:10px';grid.after(box);}const nextBanks=YOUSSEFRelay.validBanks(DB._cache),nextRecover=Object.entries(DB._cache.saved_time||{}).filter(([,b])=>b.status==='restoring'),sig=JSON.stringify([nextBanks,nextRecover,YOUSSEFRelay.entries(posts()).map(({p,i})=>[p.num,!!active(p,i).actif,!!active(p,i).starting]),Array.from(busy)]);if(box.dataset.signature===sig)return;box.dataset.signature=sig;box.replaceChildren();const title=document.createElement('b');title.textContent='💾 TEMPS SAUVEGARDÉS — valables jusqu’à 8 h';box.append(title);const banks=YOUSSEFRelay.validBanks(DB._cache),recover=Object.entries(DB._cache.saved_time||{}).filter(([,b])=>b.status==='restoring');if(!banks.length&&!recover.length){const text=document.createElement('p');text.textContent='Aucun temps sauvegardé pour cette journée.';box.append(text);return;}
 for(const [bankId,b]of [...banks,...recover]){const row=document.createElement('div');row.style.cssText='padding:10px 0;border-top:1px solid #735b9b;margin-top:10px';const info=document.createElement('p');info.textContent=b.client+' · '+format(b.remainingSeconds)+' · '+(b.status==='restoring'?'restauration à terminer':'expire à 8 h');row.append(info);const select=document.createElement('select');select.style.cssText='padding:8px;max-width:100%';for(const {p,i}of YOUSSEFRelay.entries(posts())){const a=active(p,i);if(b.status==='restoring'?p.num!==b.restorePoste:a.actif||a.starting)continue;const option=document.createElement('option');option.value=i;option.textContent=YOUSSEFRelay.displayName(p)+(b.status==='restoring'?' — terminer la restauration':' — libre');select.append(option);if(p.num===b.poste)option.selected=true;}const button=document.createElement('button');button.textContent='↩ RESTAURER LE TEMPS';button.style.cssText='padding:10px;margin:8px;background:#7c3aed;color:white;border:0;border-radius:8px';button.disabled=!select.options.length;button.onclick=()=>w.youssefRestoreTime(bankId,select.value);row.append(select,button);if(!select.options.length){const message=document.createElement('small');message.textContent='Aucun poste libre : le temps reste sauvegardé.';row.append(message);}box.append(row);}
}
for(const name of patron?['renderControl']:['renderPostes']){const old=w[name];w[name]=function(...args){const result=old.apply(this,args);drawBanks();return result;};}
if(!patron){
 // No root read and no old-day revenue in the manager's browser.
 createRestRoot=()=>YOUSSEFRelay.restRoom();
 const sanitize=()=>{const key=YOUSSEFRelay.dayKey(),root=DB._cache||{},ss=root.sessions;root.daily={[key]:root.daily?.[key]||{recettes:0}};root.activity_daily={[key]:root.activity_daily?.[key]||{}};if(!ss||ss.dayStart!==YOUSSEFRelay.dayStart())root.sessions={recettes:0,count:0,date:today(),parPoste:{},sessionsParPoste:{},payStats:{},dayStart:YOUSSEFRelay.dayStart()};for(const id of ['s-yesterday','s-month']){const el=document.getElementById(id);if(el){el.textContent='';el.parentElement.hidden=true;}}};
 const oldRefresh=refreshFromRemote;refreshFromRemote=function(...args){sanitize();return oldRefresh.apply(this,args);};
 const oldStats=updateStats;updateStats=function(...args){sanitize();return oldStats.apply(this,args);};
 ensureDailyRollover=function(){const key=YOUSSEFRelay.dayKey();if(runtimeDayKey===key)return false;runtimeDayKey=key;sanitize();recettes=0;sessDone=0;recettesParPoste={};sessionsParPoste={};payStats={};return true;};
 addJournal=function(color,main,detail,amount,motif='',extra={}){const stamp=Date.now(),key=YOUSSEFRelay.dayKey(),event={...extra,color,main,detail,amount,motif,ts:stamp,dateKey:key,t:new Date(stamp).toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'}),actorRole:'gerant',uid:YOUSSEFRelay.currentUid()};YOUSSEFRelay.child(YOUSSEFRelay.room+'/activity_daily/'+key+'/'+crypto.randomUUID()).set(event).catch(()=>{});};
}
// Network loss is not evidence that the physical plug went OFF.
if(patron&&typeof ownerAutoPause==='function')ownerAutoPause=async()=>false;
const style=document.createElement('style');style.textContent='#youssef-saved-times select{background:#171123;color:white;border:1px solid #735b9b;border-radius:8px}';document.head.append(style);
let lastDay=YOUSSEFRelay.dayKey();setInterval(()=>{if(typeof DB==='undefined'||!DB._cache)return;const nextDay=YOUSSEFRelay.dayKey();if(lastDay!==nextDay){lastDay=nextDay;if(!patron){ensureDailyRollover();updateStats();renderRapport();}drawBanks();}DB._cache=YOUSSEFRelay.syncPhysicalRoot(DB._cache);drawBanks();},1000);
})(window);




