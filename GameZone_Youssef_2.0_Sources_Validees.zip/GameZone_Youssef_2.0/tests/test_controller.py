import copy,json,math,socket,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch,Mock
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'relais'))
from pilotage_core import Controller,Journal,validate_pilotage
from pilotage_runner import PilotageRunner
from firebase_transport import FirebaseTransport,FirebaseConflict
from room_identity import OWNER_UID as OWNER,RELAY_UID as RELAY,DB_URL as DB,API_KEY,IDS,runtime_config


class Clock:
    def __init__(self): self.t = 1800000000
    def __call__(self): return self.t
    def advance(self, seconds): self.t += seconds

def command(clock, action='start', seconds=120, cid='0123456789abcdef-one'):
    return {'id': cid, 'by': OWNER, 'action': action, 'seconds': seconds,
            'createdAt': round(clock()*1000), 'expiresAt': round(clock()*1000)+20000}

class Plug:
    def __init__(self, clock):
        self.clock, self.power, self.deadline = clock, False, None
        self.writes = []
        self.reject_timer = False
        self.clear_on = False
        self.after_arm = None
        self.offline = False
    def set_socketTimeout(self, value): pass
    def set_socketRetryLimit(self, value): pass
    def set_socketPersistent(self, value): pass
    def close(self): pass
    def remaining(self):
        if self.deadline is None: return 0
        if self.deadline <= self.clock():
            self.power = not self.power  # A native countdown can toggle OFF -> ON.
            self.deadline = None
            return 0
        return math.ceil(self.deadline-self.clock())
    def status(self):
        if self.offline: raise OSError('simulated plug disconnected')
        value = self.remaining()
        if self.after_arm:
            callback, self.after_arm = self.after_arm, None
            callback()
        return {'dps': {'1': self.power, '9': value}}
    def turn_on(self):
        self.writes.append(('on',))
        self.power = True
        if self.clear_on: self.deadline = None
    def turn_off(self):
        self.writes.append(('off',))
        self.power = False
    def set_timer(self, seconds, dps_id=9):
        self.writes.append(('timer',seconds))
        if self.reject_timer: return {'Error':'simulated rejection'}
        self.deadline = self.clock()+seconds if seconds else None

class Response:
    def __init__(self, data=None, status=200, headers=None):
        self.data, self.status_code = data, status
        self.headers = headers or {}
    def json(self): return copy.deepcopy(self.data)

class Session:
    def __init__(self, responses=None, auth=None):
        self.responses, self.calls, self.posts = list(responses or []), [], []
        self.auth = auth or {'user_id': RELAY, 'id_token': 'test-id-token',
                             'refresh_token': 'test-rotated', 'expires_in': '3600'}
    def post(self, url, **kwargs):
        self.posts.append((url,kwargs))
        return Response(self.auth)
    def request(self, method, url, **kwargs):
        self.calls.append((method,url,kwargs))
        if not self.responses: raise AssertionError('Unexpected network request')
        response = self.responses.pop(0)
        if isinstance(response,Exception): raise response
        return response

class Bridge:
    def __init__(self): self.messages=[]
    def shouldStop(self): return False
    def shouldCheck(self): return False
    def report(self, value): self.messages.append(value)
    def snapshot(self, value): pass

class Functional(unittest.TestCase):
    def setUp(self):
        self.clock = Clock()
        self.plug = Plug(self.clock)
        self.ctrl = Controller(self.plug, now=self.clock)

    def execute(self, action, seconds=0):
        return self.ctrl.execute(command(self.clock,action,seconds),OWNER)

    def test_start_confirms_native_timer_before_on(self):
        row=self.execute('start',120)
        self.assertEqual(self.plug.writes[:2],[('timer',120),('on',)])
        self.assertEqual((row['mode'],row['remaining'],row['power']),('actif',120,True))

    def test_pause_add_and_resume_preserve_credit(self):
        self.execute('start',120); self.clock.advance(20)
        paused=self.execute('pause')
        self.assertEqual((paused['remaining'],paused['power'],paused['nativeSeconds']),(100,False,0))
        writes=list(self.plug.writes)
        self.assertEqual(self.execute('add',30)['remaining'],130)
        self.assertEqual(writes,self.plug.writes)
        self.clock.advance(1000)
        resumed=self.execute('resume')
        self.assertEqual((resumed['remaining'],resumed['power']),(130,True))

    def test_add_running_does_not_send_another_on(self):
        self.execute('start',100); self.clock.advance(10)
        self.plug.writes.clear()
        row=self.execute('add',60)
        self.assertEqual(row['remaining'],150)
        self.assertEqual(self.plug.writes,[('timer',150)])

    def test_off_cancels_timer_and_cannot_toggle_back_on(self):
        self.execute('start',120); self.plug.writes.clear()
        row=self.execute('off')
        self.assertEqual(self.plug.writes,[('off',),('timer',0)])
        self.assertEqual((row['remaining'],row['mode']),(0,'libre'))
        self.clock.advance(500)
        self.assertFalse(self.plug.status()['dps']['1'])

    def test_restart_adopts_existing_timer_without_any_write(self):
        self.plug.power=True; self.plug.deadline=self.clock()+450
        row=self.ctrl.observe()
        self.assertEqual((row['remaining'],row['nativeSeconds']),(450,450))
        self.assertEqual(self.plug.writes,[])

    def test_restart_does_not_extend_an_expired_durable_deadline(self):
        self.plug.power=True;self.plug.deadline=self.clock()+300
        self.ctrl=Controller(self.plug,{'mode':'actif','deadline':self.clock()-1,'remaining':300},now=self.clock)
        self.assertEqual(self.ctrl.observe()['remaining'],0)
        self.assertFalse(self.plug.power)
        self.assertNotIn(('on',),self.plug.writes)

    def test_manual_pause_survives_restart_and_external_on(self):
        self.ctrl=Controller(self.plug,{'mode':'pause','deadline':0,'remaining':77},now=self.clock)
        self.plug.power=True
        row=self.ctrl.observe()
        self.assertEqual((row['mode'],row['remaining'],row['power']),('pause',77,False))
        self.assertNotIn(('on',),self.plug.writes)

    def test_power_failure_preserves_credit_without_auto_on(self):
        self.execute('start',120); self.clock.advance(20)
        self.plug.power=False; self.plug.deadline=None; self.plug.writes.clear()
        row=self.ctrl.observe()
        self.assertEqual((row['mode'],row['remaining']),('coupure',100))
        self.assertEqual(self.plug.writes,[])

    def test_expired_native_timer_closes_session(self):
        self.execute('start',10); self.clock.advance(10)
        row=self.ctrl.observe()
        self.assertEqual((row['mode'],row['remaining'],row['power']),('termine',0,False))

    def test_external_timer_removed_sends_only_off(self):
        self.execute('start',120); self.plug.deadline=None; self.plug.writes.clear()
        row=self.ctrl.observe()
        self.assertEqual((row['mode'],row['power']),('coupure',False))
        self.assertNotIn(('on',),self.plug.writes)

    def test_rejected_native_timer_never_sends_on(self):
        self.plug.reject_timer=True
        with self.assertRaises(RuntimeError): self.execute('start',120)
        self.assertNotIn(('on',),self.plug.writes)

    def test_firmware_clears_timer_on_on_is_repaired_once_and_confirmed(self):
        self.plug.clear_on=True
        row=self.execute('start',120)
        self.assertTrue(row['power']);self.assertGreater(row['nativeSeconds'],0)
        self.assertEqual(self.plug.writes.count(('on',)),1)
        self.assertEqual(self.plug.writes.count(('timer',120)),2)

    def test_expiry_between_timer_and_on_cleans_up_without_on(self):
        original=self.plug.set_timer
        def arm(seconds,dps_id=9):
            result=original(seconds,dps_id)
            if seconds: self.plug.after_arm=lambda:self.clock.advance(21)
            return result
        self.plug.set_timer=arm
        with self.assertRaises(RuntimeError): self.execute('start',120)
        self.assertNotIn(('on',),self.plug.writes)
        self.assertFalse(self.plug.power)
        self.assertEqual(self.plug.remaining(),0)

    def test_pause_has_no_automatic_resume_after_elapsed_time(self):
        self.execute('start',120); self.execute('pause'); self.plug.writes.clear()
        self.clock.advance(600)
        self.assertEqual(self.ctrl.observe()['remaining'],120)
        self.assertEqual(self.plug.writes,[])

    def test_add_cannot_exceed_24_hours(self):
        self.execute('start',86400); self.plug.writes.clear()
        with self.assertRaises(RuntimeError): self.execute('add',1)
        self.assertEqual(self.plug.writes,[])

    def test_start_cannot_overwrite_running_session(self):
        self.execute('start',100); self.plug.writes.clear()
        with self.assertRaises(RuntimeError): self.execute('start',10)
        self.assertEqual(self.plug.writes,[])

    def test_invalid_commands_have_no_physical_effect(self):
        base=command(self.clock)
        variations=[dict(base,by='other'),dict(base,expiresAt=base['createdAt']),
            dict(base,createdAt=float('nan')),dict(base,seconds=True),
            dict(base,action='unknown'),dict(base,seconds=-1)]
        for row in variations:
            with self.assertRaises(ValueError): self.ctrl.execute(row,OWNER)
        self.assertEqual(self.plug.writes,[])
