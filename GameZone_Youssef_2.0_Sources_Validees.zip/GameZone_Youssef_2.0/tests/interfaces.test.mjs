import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {webcrypto} from 'node:crypto';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const OWNER='EH5EZIwCaiNwZgm0VYwVABI5IzV2';
const DB='https://gamzone-youssef-7e8ae-default-rtdb.firebaseio.com';
function fixture(role){
 const calls=[],data={pilotage_v1:{heartbeat:{at:Date.now(),capabilities:['command-receipts-v2','saved-time-v1']},states:Object.fromEntries(Array.from({length:7},(_,i)=>[i+1,{online:true,power:false,seenAt:Date.now(),mode:'libre',nativeSeconds:0,remaining:0}]))}};
 const fetch=async(url,options={})=>{
  const u=new URL(url);assert.equal(u.origin,DB);calls.push({url:u.toString(),method:options.method});
  const segments=u.pathname.slice(1,-5).split('/').map(decodeURIComponent);let node=data;
  for(const k of segments.slice(0,-1))node=node[k]??={};const key=segments.at(-1);
  if(options.method==='PUT'){
   node[key]=JSON.parse(options.body);
   if(segments[0]==='pilotage_v1'&&segments[1]==='commands'){
    const c=node[key],s=data.pilotage_v1.states[key];
    s.result={id:c.id,ok:true};s.seenAt=Date.now();
    if(c.action==='start'){s.power=true;s.mode='actif';s.remaining=c.seconds;s.nativeSeconds=c.seconds;s.deadline=Date.now()+c.seconds*1000;}
   }
  }
  if(options.method==='DELETE')delete node[key];
  return new Response(JSON.stringify(node[key]??null),{status:200,headers:{ETag:'"test"',Date:new Date().toUTCString()}});
 };
 const w={fetch,dispatchEvent(){}};
 const sandbox={window:w,fetch,document:{getElementById(){return null;}},crypto:webcrypto,Response,AbortController,console,CustomEvent:class{},setInterval(){},setTimeout,clearTimeout,Date,Map,Set};
 vm.createContext(sandbox);vm.runInContext(fs.readFileSync(path.join(root,role,'youssef-relay.js'),'utf8'),sandbox);
 const api=w.YOUSSEFRelay;api.install({uid:()=>OWNER,token:async()=> 'test-token'});
 return {api,calls,data};
}
for(const role of ['patron','gerant']){
 test(`${role}: all seven labels map without stealing bonus or gym`,()=>{
  const {api}=fixture(role);for(let i=1;i<=7;i++)assert.equal(api.poste({num:`Poste ${i} ps3`}),String(i));
  for(const n of ['Poste 8','Poste 17','Bonus','Gymnastique'])assert.throws(()=>api.poste(n));
 });
 test(`${role}: preserve indices, labels, tariffs and only deduplicate physical controls`,()=>{
  const {api}=fixture(role);const posts=Array.from({length:7},(_,i)=>({num:`Poste ${i+1}`,displayName:`Mon poste ${i+1}`}));
  const entries=api.entries([...posts,{num:'Bonus'},{num:'Poste 7 ps3'}]);assert.equal(entries.length,7);assert.equal(entries[6].i,6);assert.equal(api.displayName(posts[6]),'Mon poste 7');
 });
 test(`${role}: foreign room paths are rejected before fetch`,async()=>{
  const {api,calls}=fixture(role);await assert.rejects(api.request('gz_OTHER/active_by_poste'));assert.ok(calls.every(x=>!x.url.includes('gz_OTHER')));
  assert.throws(()=>api.child('gz_OTHER/postes'));
 });
 test(`${role}: native command receipt on poste seven`,async()=>{
  const {api,calls}=fixture(role);const s=await api.command({num:'Poste 7'},'start',120);
  assert.equal(s.power,true);assert.equal(s.nativeSeconds,120);
  assert.equal(calls.filter(x=>x.method==='PUT'&&x.url.includes('/commands/7.json')).length,1);
  assert.ok(calls.every(x=>x.url.startsWith(DB+'/')));
 });
 test(`${role}: unread seventh plug makes total unknown`,()=>{
  const {api}=fixture(role);assert.equal(api.physicalSummary().unknown.length,7);assert.equal(api.physicalSummary().count,'—');
 });
 test(`${role}: paid start and reduce produce physical actions`,()=>{
  const {api}=fixture(role),p={num:'Poste 7'},key=encodeURIComponent(p.num),now=Date.now();
  const old={postes:[p],active_by_poste:{}};let next={postes:[p],active_by_poste:{[key]:{actif:true,finTs:now+120000}}};
  assert.equal(api.plan(old,next)[0].action,'start');const reduced=structuredClone(next);reduced.active_by_poste[key].finTs-=60000;
  assert.equal(api.plan(next,reduced)[0].action,'subtract');assert.equal(api.plan(next,reduced)[0].seconds,60);
 });
 test(`${role}: old physical receipt cannot freeze resumed session`,()=>{
  const {api}=fixture(role),state={actif:true,paused:false,sessionId:'s',nativeCommandId:'new',startedAt:100};
  assert.equal(api.applyPause(state,{sessionId:'s',nativeId:'old',at:200,remaining:20}).paused,false);
 });
 test(`${role}: no automatic tariff replacement on login`,async()=>{
  const {api,calls}=fixture(role);await api.importTariffs();assert.equal(calls.filter(x=>x.method==='PUT').length,0);
 });
}
test('every local script exists and parses; no CP1 URL, account, device or room remains',()=>{
 const forbidden=/GZ-07732|gamezone-bah-nouveau|Jt6csGJG|zmoFFHKW|bf77859fcb75e26cf11f4o|workers\.dev/;
 for(const role of ['patron','gerant']){
  const dir=path.join(root,role),html=fs.readFileSync(path.join(dir,'index.html'),'utf8');assert.ok(!forbidden.test(html));
  for(const match of html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)){
   const src=match[1].match(/src="([^"]+)"/);if(src){if(!src[1].startsWith('https:'))assert.ok(fs.existsSync(path.join(dir,src[1].split('?')[0])));}else new vm.Script(match[2]);
  }
  for(const f of fs.readdirSync(dir).filter(x=>x.endsWith('.js'))){const s=fs.readFileSync(path.join(dir,f),'utf8');new vm.Script(s);assert.ok(!forbidden.test(s),f);}
 }
});
test('browser persistence is explicitly scoped by room AND role',()=>{
 for(const role of ['patron','gerant'])assert.ok(fs.readFileSync(path.join(root,role,'index.html'),'utf8').includes(`gamezone:abou-youssef:${role}:`));
});
