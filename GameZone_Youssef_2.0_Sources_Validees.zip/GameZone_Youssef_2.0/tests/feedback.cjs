const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
(async()=>{
 const played=[],events={},timers=[],memory=new Map(),notifications=[];
 const button={textContent:'',title:''};
 const document={readyState:'loading',getElementById:id=>id==='gz-notify-btn'?button:null,addEventListener:(n,fn)=>events[n]=fn,createElement:()=>({style:{}}),head:{append(){}},body:{append(){}}};
 const w={addEventListener:(n,fn)=>events['window:'+n]=fn,ownerSpeak:()=>false,GZMaleSpeech:{selectedVoice:()=>null}};
 const sandbox={window:w,document,console,Date,Audio:class{constructor(src){this.src=src}play(){played.push(this.src);return Promise.resolve()}pause(){}},localStorage:{getItem:k=>memory.get(k)||null,setItem:(k,v)=>memory.set(k,v)},sessionStorage:{getItem:k=>memory.get(k)||null,setItem:(k,v)=>memory.set(k,v)},setInterval:f=>timers.push(f),Notification:{permission:'granted'},navigator:{serviceWorker:{getRegistration:async()=>({showNotification:async(...args)=>notifications.push(args)})}},DB:{_cache:{active_by_poste:{'Poste%201':{actif:true,paused:false,sessionId:'one',finTs:Date.now()+120000}}}}};
 w.Notification=sandbox.Notification;vm.createContext(sandbox);vm.runInContext(fs.readFileSync(__dirname+'/../patron/youssef-feedback.js','utf8'),sandbox);events['window:load']();
 assert.equal(w.ownerSpeak('Il reste cinq minutes.'),true);assert.ok(played.at(-1).includes('youssef-audio-five.mp3'));
 assert.equal(w.GZActionAudio.classify('REPRENDRE'),'resume');assert.equal(w.GZActionAudio.classify('ACTIVER'),'start');assert.equal(w.GZActionAudio.classify('+TPS'),'add');
 events.click({target:{closest:()=>({disabled:false,textContent:'PAUSE',id:'pause',closest:()=>null})}});assert.ok(played.at(-1).includes('pause.mp3'));
 timers[0]();await new Promise(setImmediate);assert.equal(notifications.length,1);timers[0]();await Promise.resolve();assert.equal(notifications.length,1);
 memory.set('youssef-audio-enabled','0');const count=played.length;w.GZActionAudio.play('start');assert.equal(played.length,count);
 console.log('Male audio without OS voice, action selection, mute, 5-minute notification deduplication: OK');
 for(const role of ['patron','gerant']){
 const html=fs.readFileSync(__dirname+'/../'+role+'/index.html','utf8');const from=html.indexOf('async function enableRealNotifications(button){'),to=html.indexOf('\n  function bind(){',from);const code=html.slice(from,to);let shown=0,permission='granted';
 const ctx={window:{isSecureContext:true,Notification:{},GZFeedback:{notificationStatus(){}}},Notification:{requestPermission:async()=>permission},navigator:{serviceWorker:{register:async()=>({showNotification:async()=>shown++}),ready:Promise.resolve()}},setTimeout:()=>1,Promise,Error};vm.createContext(ctx);vm.runInContext(code,ctx);await ctx.enableRealNotifications({});assert.equal(shown,1);permission='denied';await assert.rejects(ctx.enableRealNotifications({}));assert.equal(shown,1);assert.ok(!code.includes('fetch('));
 console.log(role+': notification permission granted/denied, no unconfigured Worker dependency: OK');
 }
})().catch(e=>{console.error(e);process.exit(1)});
