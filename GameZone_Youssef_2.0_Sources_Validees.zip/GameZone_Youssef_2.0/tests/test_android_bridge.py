import importlib.util
import json
import pathlib
import sys
import unittest
from unittest.mock import patch, MagicMock
ROOT=pathlib.Path(__file__).resolve().parents[1]
APK=ROOT/'android'
sys.path.insert(0,str(APK/'app/src/main/python'))
from room_identity import DB_URL, OWNER_UID, RELAY_UID, API_KEY, IDS

class AndroidBridgeTests(unittest.TestCase):
 def test_embedded_runner_uses_youssef_identity_and_closes_transport(self):
  spec=importlib.util.spec_from_file_location('apk_engine',APK/'app/src/main/python/engine.py')
  module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
  config=dict(url=DB_URL,room='abou-youssef',protocol='pilotage_v1',transport='firebase',apiKey=API_KEY,
   ownerUid=OWNER_UID,relayUid=RELAY_UID,refreshToken='test-only-refresh-token',
   postes={str(n):did for n,did in IDS.items()},devices={did:dict(ip='192.168.2.'+str(n+100),key='1234567890123456',version=3.5) for n,did in IDS.items()})
  session=MagicMock();bridge=object()
  with patch.dict(sys.modules, {'requests':MagicMock(Session=MagicMock(return_value=session))}),patch('pilotage_runner.PilotageRunner') as runner:
   runner.return_value.run.return_value='stopped'
   self.assertEqual(module.run('/tmp/test-youssef',json.dumps(config),bridge),'stopped')
   args=runner.call_args.args
   self.assertEqual(args[1]['room'],'abou-youssef');self.assertEqual(len(args[1]['devices']),7)
   self.assertIs(args[2],bridge);self.assertFalse(session.trust_env);session.close.assert_called_once()
   runner.return_value.run.side_effect=OSError('offline')
   with self.assertRaises(OSError):module.run('/tmp/test-youssef',json.dumps(config),bridge)
   self.assertEqual(session.close.call_count,2)
 def test_apk_and_termux_engines_share_the_same_controller(self):
  for name in ['pilotage_core.py','pilotage_runner.py','firebase_transport.py','business.py','room_identity.py']:
   self.assertEqual((ROOT/'relais'/name).read_bytes(),(APK/'app/src/main/python'/name).read_bytes(),name)

if __name__=='__main__':unittest.main()
