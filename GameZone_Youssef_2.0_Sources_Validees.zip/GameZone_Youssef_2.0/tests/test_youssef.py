import copy,json,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import Mock
from test_controller import Clock,Plug,command
from room_identity import *
from engine import validate_import
from pilotage_core import Controller,Journal
from pilotage_runner import PilotageRunner,business_post
from firebase_transport import FirebaseTransport
from business import apply_confirmed,shift
from relais_firebase import build_config

def config():
    return dict(url=DB_URL,room='abou-youssef',protocol='pilotage_v1',transport='firebase',apiKey=API_KEY,
        ownerUid=OWNER_UID,relayUid=RELAY_UID,refreshToken='test-only',agent='test-agent',
        postes={str(n):did for n,did in IDS.items()},
        devices={did:dict(ip='192.168.10.'+str(100+n),key='0'*16,version=3.5) for n,did in IDS.items()})

class Isolation(unittest.TestCase):
    def test_exact_seven_configuration_is_valid(self):
        self.assertEqual(len(json.loads(validate_import(json.dumps(config()),'{}'))['postes']),7)
    def test_other_project_rejected_before_network(self):
        c=config();c['url']='https://other.firebaseio.com'
        with self.assertRaises(ValueError):runtime_config(c)
    def test_other_owner_rejected(self):
        c=config();c['ownerUid']='another-owner'
        with self.assertRaises(ValueError):runtime_config(c)
    def test_other_relay_rejected(self):
        c=config();c['relayUid']='another-relay'
        with self.assertRaises(ValueError):runtime_config(c)
    def test_swapped_physical_mapping_rejected(self):
        c=config();c['postes']['1'],c['postes']['7']=c['postes']['7'],c['postes']['1']
        with self.assertRaises(ValueError):runtime_config(c)
    def test_eighth_plug_rejected(self):
        c=config();c['postes']['8']='foreign';c['devices']['foreign']=c['devices'][IDS[1]]
        with self.assertRaises(ValueError):runtime_config(c)
    def test_other_firebase_key_rejected(self):
        c=config();c['apiKey']='foreign'
        with self.assertRaises(ValueError):runtime_config(c)
    def test_labels_match_all_seven_without_console_assumption(self):
        for n in range(1,8):
            for label in [f'Poste {n}',f'Poste {n} ps3',f'Poste {n} PS4 flech']:
                self.assertEqual(business_post(label),str(n))
        for label in ['Poste 8','Poste 17','Bonus','Gymnastique']:self.assertEqual(business_post(label),'')
    def test_transport_business_path_is_youssef(self):
        session=Mock();session.request.return_value=Mock(status_code=200,headers={})
        t=FirebaseTransport(DB_URL,'test-token',session,room='abou-youssef',relay_uid=RELAY_UID,protocol='pilotage_v1')
        t.request('GET','active_by_poste',business=True)
        self.assertEqual(session.request.call_args.args[1],DB_URL+'/gz_YOUSSEF/active_by_poste.json')
    def test_transport_rejects_foreign_project_before_request(self):
        session=Mock()
        with self.assertRaises(ValueError):FirebaseTransport('https://other.firebaseio.com','test',session,room='abou-youssef',relay_uid=RELAY_UID,protocol='pilotage_v1')
        session.request.assert_not_called()

class Commands(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.clock=Clock();self.bridge=Mock();self.bridge.shouldStop.return_value=False
        self.r=PilotageRunner(self.tmp.name,config(),self.bridge,Mock(),factory=lambda *a,**kw:Plug(self.clock))
        self.r.transport.clock=self.clock;self.r.active.set();self.r.local_safety.set()
    def execute(self,poste,action,seconds=0,cid=None,by=OWNER_UID):
        c=command(self.clock,action,seconds,cid or 'command-'+action+'-00000000000');c['by']=by
        self.assertTrue(self.r.submit(poste,c));q=self.r.queues[poste].get_nowait();self.r.process(poste,q);self.r.queued.discard(c['id']);return self.r.status[poste]
    def test_poste_seven_only_receives_its_command(self):
        s=self.execute('7','start',120);self.assertTrue(s['result']['ok']);self.assertEqual(s['nativeSeconds'],120)
        for n,c in self.r.controllers.items():
            if n!='7':self.assertEqual(c.d.writes,[])
    def test_duplicate_command_never_extends_time(self):
        cid='command-start-00000000000';self.execute('7','start',120,cid)
        writes=copy.deepcopy(self.r.controllers['7'].d.writes)
        self.assertFalse(self.r.submit('7',command(self.clock,'start',120,cid)))
        self.assertEqual(writes,self.r.controllers['7'].d.writes)
    def test_staff_can_start_add_subtract_pause_resume(self):
        response=Mock();response.json.return_value='gerant';self.r.transport.request=Mock(return_value=response)
        for action,sec in [('start',120),('add',60),('subtract',30),('pause',0),('resume',0)]:
            self.assertTrue(self.execute('7',action,sec,by='staff123')['result']['ok'])
    def test_staff_off_is_refused_without_socket_effect(self):
        response=Mock();response.json.return_value='gerant';self.r.transport.request=Mock(return_value=response)
        with self.assertRaises(ValueError):self.execute('7','off',by='staff123')
        self.assertEqual(self.r.controllers['7'].d.writes,[])
    def test_revoked_staff_cannot_submit(self):
        response=Mock();response.json.return_value=None;self.r.transport.request=Mock(return_value=response)
        with self.assertRaises(ValueError):self.execute('7','start',120,by='staff123')
        self.assertEqual(self.r.controllers['7'].d.writes,[])
    def test_save_returns_confirmed_credit_and_cancels_native_timer(self):
        self.execute('7','start',120);self.clock.advance(20)
        s=self.execute('7','save');self.assertEqual(s['result']['savedSeconds'],100)
        self.assertEqual((s['power'],s['nativeSeconds'],s['mode']),(False,0,'libre'))
    def test_subtract_to_zero_confirms_off(self):
        self.execute('7','start',120);s=self.execute('7','subtract',120)
        self.assertEqual((s['power'],s['nativeSeconds'],s['remaining']),(False,0,0))
    def test_native_expiry_has_no_automatic_on(self):
        self.execute('7','start',120);self.clock.advance(120);p=self.r.controllers['7'].d;p.writes.clear()
        s=self.r.controllers['7'].observe();self.assertEqual(s['mode'],'termine');self.assertFalse(s['power']);self.assertNotIn(('on',),p.writes)

class Business(unittest.TestCase):
    def setUp(self):
        self.now=1800000000000;day,start,date=shift(self.now)
        self.root=dict(postes=[dict(num='Poste 7 ps3')],active_by_poste={'Poste%207%20ps3':dict(actif=True,sessionId='session-seven',nativeCommandId='native-seven',startedAt=self.now-120000,montantSession=100,finTs=self.now)},
            active_postes=[{}],sessions=dict(dayStart=start,date=date,recettes=100,count=0),daily={day:dict(dayStart=start,recettes=100,count=0)})
        self.states={'7':dict(online=True,power=False,mode='termine',nativeSeconds=0,remaining=0,seenAt=self.now,result={'id':'native-seven'})}
    def test_expiry_closes_once_and_keeps_revenue(self):
        a=apply_confirmed(self.root,self.states,self.now);b=apply_confirmed(a,self.states,self.now)
        self.assertEqual(a,b);self.assertEqual(a['sessions']['recettes'],100);self.assertEqual(a['sessions']['count'],1)
        self.assertFalse(a['active_by_poste']['Poste%207%20ps3']['actif'])
    def test_unknown_plug_does_not_close_session(self):
        self.states['7']['online']=False;a=apply_confirmed(self.root,self.states,self.now)
        self.assertTrue(a['active_by_poste']['Poste%207%20ps3']['actif'])
    def test_stale_receipt_does_not_close_new_session(self):
        self.states['7']['result']['id']='old';a=apply_confirmed(self.root,self.states,self.now)
        self.assertTrue(a['active_by_poste']['Poste%207%20ps3']['actif'])
    def test_current_legacy_day_keeps_revenue_on_upgrade(self):
        self.root['sessions'].pop('dayStart');a=apply_confirmed(self.root,{},self.now)
        self.assertEqual(a['sessions']['recettes'],100)
    def test_rollover_archives_without_touching_active_deadline(self):
        old=copy.deepcopy(self.root);a=apply_confirmed(self.root,{},self.now+86400000)
        self.assertEqual(a['sessions']['recettes'],0);self.assertTrue(a['rollover_archives'])
        self.assertEqual(a['active_by_poste']['Poste%207%20ps3']['finTs'],old['active_by_poste']['Poste%207%20ps3']['finTs'])

class ReceiptsAndLease(unittest.TestCase):
    def transport(self,session):
        t=FirebaseTransport(DB_URL,'test-token',session,room='abou-youssef',relay_uid=RELAY_UID,protocol='pilotage_v1',agent='this-agent')
        t.clock=lambda:1800000000
        return t
    def test_live_other_relay_cannot_be_stolen(self):
        from test_controller import Response,Session
        session=Session([Response({'at':1800000000000,'agent':'other-agent'},headers={'Date':'Fri, 15 Jan 2027 08:00:00 GMT','ETag':'"1"'})])
        # Fixed server time must agree with the recent heartbeat.
        session.responses[0].headers['Date']='Fri, 15 Jan 2027 08:00:00 GMT'
        import email.utils
        stamp=email.utils.parsedate_to_datetime(session.responses[0].headers['Date']).timestamp()*1000
        session.responses[0].data['at']=stamp
        self.assertFalse(self.transport(session).heartbeat())
        self.assertEqual(len(session.calls),1)
    def test_stale_relay_requires_conditional_takeover(self):
        from test_controller import Response,Session
        session=Session([Response({'at':0,'agent':'old'},headers={'Date':'Fri, 15 Jan 2027 08:00:00 GMT','ETag':'"1"'}),Response({})])
        self.assertTrue(self.transport(session).heartbeat())
        self.assertEqual(session.calls[1][2]['headers']['if-match'],'"1"')
    def test_numeric_command_array_keeps_seventh_entry(self):
        from test_controller import Response,Session
        session=Session([Response([None,None,None,None,None,None,None,{'id':'seven'}])])
        self.assertEqual(self.transport(session).pending(),{'7':{'id':'seven'}})
    def test_saved_credit_and_receipt_are_one_durable_record(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'journal.json';j=Journal(p);j.complete_saved('7','save-command-12345',75)
            restored=Journal(p)
            self.assertEqual(restored.receipt('7')['savedSeconds'],75)
            self.assertEqual(restored.data['sessions']['7']['remaining'],0)
    def test_failed_save_keeps_credit_durably_paused(self):
        clock=Clock();plug=Plug(clock);saved=[];ctrl=Controller(plug,now=clock,persist=lambda x:saved.append(copy.deepcopy(x)))
        ctrl.execute(command(clock,'start',120),OWNER_UID)
        plug.turn_off=lambda:(_ for _ in ()).throw(OSError('test-only'))
        with self.assertRaises(OSError):ctrl.execute(command(clock,'save',0),OWNER_UID)
        self.assertEqual(saved[-1]['mode'],'pause');self.assertEqual(saved[-1]['remaining'],120)

if __name__=='__main__':unittest.main()
