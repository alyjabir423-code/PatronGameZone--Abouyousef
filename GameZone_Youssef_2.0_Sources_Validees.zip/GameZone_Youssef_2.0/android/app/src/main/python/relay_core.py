import ipaddress
import json
import os
from pathlib import Path


def save(path, value):
    tmp = path.with_suffix('.tmp')
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, 'w') as f:
        json.dump(value, f)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)
    os.chmod(path, 0o600)

def load(path, default=None):
    if not path.exists():
        return default
    with path.open() as f:
        return json.load(f)

def discovered_addresses(rows, allowed):
    """Accept unique private IPv4 announcements for known IDs only."""
    candidates = {}
    for address, row in rows.items():
        if not isinstance(row, dict):
            continue
        did = row.get('gwId') or row.get('id') or row.get('dev_id')
        try:
            ip = ipaddress.ip_address(row.get('ip') or address)
        except ValueError:
            continue
        if did not in allowed or ip.version != 4 or not ip.is_private or ip.is_loopback or ip.is_unspecified:
            continue
        candidates.setdefault(did, set()).add(str(ip))
    unique = {did: next(iter(ips)) for did, ips in candidates.items() if len(ips) == 1}
    return {did: ip for did, ip in unique.items() if list(unique.values()).count(ip) == 1}
