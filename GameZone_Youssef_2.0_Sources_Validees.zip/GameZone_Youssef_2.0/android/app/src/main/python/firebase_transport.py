"""Firebase Auth + RTDB for relay_commands and YOUSSEF pilotage_v1."""
import math
import threading
import time
from email.utils import parsedate_to_datetime
from urllib.parse import quote, urlsplit


def validate_database_url(value):
    u = urlsplit(value)
    if (u.scheme != 'https' or not u.hostname or u.username or u.password
            or u.port not in (None, 443) or u.path not in ('', '/') or u.query or u.fragment
            or not (u.hostname.endswith('.firebaseio.com') or u.hostname.endswith('.firebasedatabase.app'))):
        raise ValueError('Adresse Firebase invalide')
    return value.rstrip('/')


def object_rows(value):
    # RTDB returns dense numeric maps as arrays, including commands/1..7.
    if isinstance(value, list):
        return {str(i): row for i, row in enumerate(value) if row is not None}
    return value if isinstance(value, dict) else {}


class FirebaseConflict(OSError):
    pass


class FirebaseTransport:
    def __init__(self, database_url, id_token, session, room='abou-youssef', *, refresh_token=None,
                 api_key=None, relay_uid=None, on_refresh=None, protocol='relay_commands',
                 agent=None, wall_clock=time.time, monotonic=time.monotonic):
        from room_identity import DB_URL, RELAY_UID
        self.database_url = validate_database_url(database_url)
        if self.database_url != DB_URL or room != 'abou-youssef' or relay_uid != RELAY_UID or protocol != 'pilotage_v1':
            raise ValueError('Configuration extérieure à Abou Youssef')
        if not ((isinstance(id_token, str) and id_token.strip()) or
                (isinstance(refresh_token, str) and refresh_token.strip())):
            raise ValueError('Authentification Firebase requise')
        if refresh_token and (not api_key or not relay_uid):
            raise ValueError('API key et UID relais requis pour le renouvellement')
        if not isinstance(room, str) or not room or len(room) > 64 or not all(c.isalnum() or c in '-_' for c in room):
            raise ValueError('Salle Firebase invalide')
        if protocol not in ('relay_commands', 'pilotage_v1'):
            raise ValueError('Protocole Firebase inconnu')
        self.protocol, self.agent = protocol, agent
        self.base = self.database_url + ('/pilotage_v1' if protocol == 'pilotage_v1' else '/relay_commands/' + room)
        self.token, self.session = id_token or '', session
        self.refresh_token, self.api_key, self.relay_uid = refresh_token, api_key, relay_uid
        self.on_refresh = on_refresh
        self.clock, self.monotonic = wall_clock, monotonic
        self.token_until = 0 if refresh_token else float('inf')
        self._auth_lock = threading.Lock()
        self.offset, self.clock_synced = 0, False

    def now(self):
        return self.clock() + self.offset

    def auth_token(self, force=False):
        if not self.refresh_token:
            return self.token
        with self._auth_lock:
            if not force and self.token and self.monotonic() < self.token_until:
                return self.token
            response = self.session.post('https://securetoken.googleapis.com/v1/token',
                params={'key': self.api_key},
                data={'grant_type': 'refresh_token', 'refresh_token': self.refresh_token},
                timeout=(3, 8), allow_redirects=False)
            if response.status_code != 200:
                raise PermissionError('Renouvellement Firebase refusé')
            data = response.json()
            if data.get('user_id') != self.relay_uid or not isinstance(data.get('id_token'), str) or not data['id_token']:
                raise PermissionError('UID Firebase du relais incorrect')
            lifetime = int(data.get('expires_in', 3600))
            if lifetime < 1:
                raise PermissionError('Durée du jeton Firebase invalide')
            rotated = data.get('refresh_token', self.refresh_token)
            if not isinstance(rotated, str) or not rotated:
                raise PermissionError('Jeton Firebase invalide')
            if rotated != self.refresh_token and self.on_refresh:
                self.on_refresh(rotated)
            self.refresh_token, self.token = rotated, data['id_token']
            self.token_until = self.monotonic() + max(1, lifetime - 120)
            return self.token

    def request(self, method, path, *, data=None, headers=None, sync_clock=False, business=False):
        if path and (not isinstance(path, str) or any(not x or any(c in x for c in '.#$[]') for x in path.split('/'))):
            raise ValueError('Chemin Firebase invalide')
        base = self.database_url + '/gz_YOUSSEF' if business else self.base
        url = base + ('/' + quote(path, safe='/') if path else '') + '.json'
        for attempt in range(2):
            token = self.auth_token(force=bool(attempt))
            args = {'params': {'auth': token}, 'headers': dict(headers or {}),
                    'timeout': (3, 5), 'allow_redirects': False}
            if data is not None:
                args['json'] = data
            sent = self.clock()
            response = self.session.request(method, url, **args)
            if response.status_code == 401 and self.refresh_token and attempt == 0:
                continue
            if response.status_code in (401, 403):
                raise PermissionError('Accès Firebase refusé ; vérifier le compte relais et les règles')
            if response.status_code == 412:
                raise FirebaseConflict('Firebase HTTP 412')
            if response.status_code not in (200, 204):
                raise OSError('Firebase HTTP ' + str(response.status_code))
            if sync_clock:
                date = response.headers.get('Date')
                if not date:
                    raise OSError('Horloge Firebase non confirmée')
                server = parsedate_to_datetime(date).timestamp()
                self.offset = server - (sent + self.clock()) / 2
                self.clock_synced = True
            return response
        raise PermissionError('Authentification Firebase refusée')

    def pending(self):
        path = 'commands' if self.protocol == 'pilotage_v1' else ''
        data = object_rows(self.request('GET', path).json())
        rows = ((k, v) for k, v in data.items() if isinstance(v, dict) and
                (self.protocol == 'pilotage_v1' or v.get('status') == 'pending'))
        return dict(list(rows)[:24])

    def states(self):
        if self.protocol != 'pilotage_v1':
            raise ValueError('États réservés à pilotage_v1')
        return object_rows(self.request('GET', 'states').json())

    def publish(self, poste, state):
        if self.protocol != 'pilotage_v1' or not str(poste).isdigit() or int(poste) < 1:
            raise ValueError('Poste Firebase invalide')
        return self.request('PUT', 'states/' + str(poste), data=state)

    def heartbeat(self):
        """CAS takeover after 60 s; legacy Termux has no agent and is also detected."""
        if self.protocol != 'pilotage_v1' or not isinstance(self.agent, str) or not self.agent:
            raise ValueError('Identité du relais absente')
        response = self.request('GET', 'heartbeat', headers={'X-Firebase-ETag': 'true'}, sync_clock=True)
        current = response.json()
        if isinstance(current, dict) and current.get('agent') != self.agent:
            stamp = current.get('at')
            if type(stamp) in (int, float) and math.isfinite(stamp) and stamp >= (self.now() - 60) * 1000:
                return False
        etag = response.headers.get('ETag')
        if not etag:
            raise OSError('ETag Firebase absent')
        try:
            self.request('PUT', 'heartbeat', headers={'if-match': etag}, data={
                'at': {'.sv': 'timestamp'}, 'agent': self.agent, 'version': 'youssef-7-v2.0', 'capabilities': ['business-v1', 'subtract', 'staff-auth', 'auto-pause-v1', 'credit-ceiling-v1', 'pending-pause-v1', 'command-receipts-v2', 'saved-time-v1']})
        except FirebaseConflict:
            return False
        return True

    def claim(self, command_id, validator, now_ms):
        if self.protocol == 'pilotage_v1':
            raise ValueError('pilotage_v1 utilise le journal local ; aucune écriture commands autorisée')
        if not isinstance(command_id, str) or not 1 <= len(command_id) <= 80 or any(c in command_id for c in '/.#$[]'):
            raise ValueError('ID Firebase invalide')
        response = self.request('GET', command_id, headers={'X-Firebase-ETag': 'true'})
        command = response.json()
        if not isinstance(command, dict):
            return None
        validated = validator(command, now_ms)
        if not response.headers.get('ETag'):
            raise OSError('ETag Firebase absent')
        try:
            self.request('PUT', command_id, data=dict(command, status='processing', claimedAt=now_ms),
                         headers={'if-match': response.headers['ETag']})
        except FirebaseConflict:
            return None
        return validated

    def complete(self, command_id, results, now_ms):
        if self.protocol == 'pilotage_v1':
            raise ValueError('Utiliser publish pour pilotage_v1')
        response = self.request('GET', command_id, headers={'X-Firebase-ETag': 'true'})
        command = response.json()
        if not isinstance(command, dict) or command.get('status') != 'processing':
            return False
        if not response.headers.get('ETag'):
            raise OSError('ETag Firebase absent')
        try:
            self.request('PUT', command_id, data=dict(command, status='done', completedAt=now_ms, results=results),
                         headers={'if-match': response.headers['ETag']})
        except FirebaseConflict:
            return False
        return True



