"""Identité stricte Abou Youssef. Aucune clé privée."""
DB_URL='https://gamzone-youssef-7e8ae-default-rtdb.firebaseio.com'
OWNER_UID='EH5EZIwCaiNwZgm0VYwVABI5IzV2'
RELAY_UID='4lYTox4BU9g9DKU0HWawCSF8CjC3'
API_KEY='AIzaSyD2SCv51__kMfypo8LhzdPnchnEUZ_05RE'
IDS={1: 'bfbd58d4767b229b4fvfmh', 2: 'bf1f677d94e54f24dckjl3', 3: 'bfe19c8306120ab526avut', 4: 'bfe0f3d8bbd479f53a6jat', 5: 'bf8d0f1db9d4b04dd7cy0h', 6: 'bf042d8aa7403cddacerx3', 7: 'bf96df80d98f3b62c3rif0'}
def runtime_config(config):
    if config.get('url','').rstrip('/') != DB_URL or config.get('room') != 'abou-youssef' or config.get('protocol') != 'pilotage_v1':
        raise ValueError('Configuration extérieure à Abou Youssef')
    if config.get('apiKey') != API_KEY:
        raise ValueError('Clé publique Firebase extérieure à Abou Youssef')
    if config.get('ownerUid') != OWNER_UID or config.get('relayUid') != RELAY_UID:
        raise ValueError('Comptes Firebase extérieurs à Abou Youssef')
    if config.get('postes') != {str(n): did for n,did in IDS.items()}:
        raise ValueError('Les sept prises Youssef doivent correspondre exactement')
    if set(config.get('devices',{})) != set(IDS.values()):
        raise ValueError('Prise extérieure à Abou Youssef')
    return dict(config)
