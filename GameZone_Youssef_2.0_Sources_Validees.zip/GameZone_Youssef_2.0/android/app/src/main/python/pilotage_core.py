"""Pilotage v1: local sockets, durable receipts, no autonomous ON.

All I/O is injected in tests. Public observations use the existing YOUSSEF
YOUSSEF states/<poste> schema, with no device key in any network payload.
"""
import copy
import math
import threading
import time
from pathlib import Path
from relay_core import save, load


MODES = {'libre', 'actif', 'pause', 'coupure', 'termine'}


def validate_pilotage(command, owner_uid, now_ms):
    if not isinstance(command, dict) or command.get('by') != owner_uid:
        raise ValueError('Auteur non autorisé')
    cid = command.get('id')
    if not isinstance(cid, str) or not 16 <= len(cid) <= 80:
        raise ValueError('Identifiant de commande invalide')
    created, expiry = command.get('createdAt'), command.get('expiresAt')
    if any(type(x) not in (int, float) or not math.isfinite(x) for x in (created, expiry)):
        raise ValueError('Dates invalides')
    if not now_ms - 60000 <= created <= now_ms + 5000 or not now_ms < expiry <= created + 30000:
        raise ValueError('Commande expirée')
    action, seconds = command.get('action'), command.get('seconds')
    if action not in ('on', 'off', 'start', 'pause', 'resume', 'add', 'subtract', 'save'):
        raise ValueError('Action inconnue')
    if type(seconds) is not int or not 0 <= seconds <= 86400:
        raise ValueError('Durée invalide')
    if action in ('start', 'add', 'subtract') and seconds == 0:
        raise ValueError('Durée requise')
    return copy.deepcopy(command)


def validate_session(row):
    if not isinstance(row, dict) or row.get('mode') not in MODES:
        raise ValueError('Session invalide')
    deadline, remaining = row.get('deadline', 0), row.get('remaining', 0)
    if type(deadline) not in (int, float) or not math.isfinite(deadline) or deadline < 0:
        raise ValueError('Échéance invalide')
    if type(remaining) is not int or not 0 <= remaining <= 86400:
        raise ValueError('Temps restant invalide')
    return {'mode': row['mode'], 'deadline': deadline, 'remaining': remaining}


class Controller:
    def __init__(self, device, saved=None, now=time.time, persist=lambda row: None,
                 cancelled=lambda: False, sleep=time.sleep):
        self.d, self.now, self.persist, self.cancelled = device, now, persist, cancelled
        self.s = validate_session(saved) if saved else {'mode': 'libre', 'deadline': 0, 'remaining': 0}
        self.expiry = None
        self.sleep = sleep

    def save(self):
        self.persist(copy.deepcopy(self.s))

    def left(self):
        if self.s['mode'] == 'actif':
            return min(86400, max(0, math.ceil(self.s['deadline'] - self.now())))
        return self.s['remaining']

    def read(self):
        data = self.d.status()
        dps = data.get('dps', {}) if isinstance(data, dict) else {}
        if not isinstance(dps, dict) or type(dps.get('1')) is not bool:
            raise RuntimeError('État de la prise non confirmé')
        timer = dps.get('9')
        if type(timer) is not int or not 0 <= timer <= 86400:
            raise RuntimeError('Minuteur natif non confirmé')
        return dps

    def call(self, method, *args, **kwargs):
        if self.cancelled():
            raise RuntimeError('Relais arrêté')
        if self.expiry is not None and self.now() * 1000 >= self.expiry - 500:
            raise RuntimeError('Commande expirée avant confirmation')
        reply = method(*args, **kwargs)
        if isinstance(reply, dict) and ('Error' in reply or 'Err' in reply):
            raise RuntimeError('La prise a refusé la commande')
        return reply

    def cleanup_off(self):
        # OFF before cancelling DP9: a remaining countdown must never toggle
        # an OFF plug back ON. Cleanup is permitted even after the command TTL.
        self.d.turn_off()
        self.d.set_timer(0, dps_id=9)
        after = self.read()
        if after['1'] or after['9'] != 0:
            raise RuntimeError('Extinction non confirmée')
        return after

    def observe(self):
        dps = self.read()
        power, timer = dps['1'], dps['9']
        mode = self.s['mode']
        changed = False
        if mode == 'actif':
            previous = self.left()
            if not power:
                self.s = {'mode': 'termine' if previous == 0 else 'coupure',
                          'deadline': 0, 'remaining': previous}
                # A countdown left while OFF can turn some plugs back ON.
                if timer:
                    self.call(self.d.set_timer, 0, dps_id=9)
                    dps = self.read()
                    if dps['9'] != 0 or dps['1']:
                        raise RuntimeError('Interruption non confirmée')
                    timer = 0
                changed = True
            elif timer > 0:
                if previous <= 0:
                    self.cleanup_off()
                    power, timer = False, 0
                    self.s = {'mode': 'termine', 'deadline': 0, 'remaining': 0}
                    changed = True
                else:
                    # A stale status after a decrease must never extend credit.
                    if timer > previous + 2:
                        self.call(self.d.set_timer, previous, dps_id=9)
                        dps = self.confirm_timer(previous)
                        power, timer = dps['1'], dps['9']
                    new_deadline = min(self.s['deadline'], self.now() + timer)
                    if abs(new_deadline - self.s['deadline']) > 1:
                        self.s['deadline'] = new_deadline
                        self.s['remaining'] = min(timer, previous)
                        changed = True
            else:
                self.cleanup_off()
                power = False
                self.s = {'mode': 'termine' if previous == 0 else 'coupure',
                          'deadline': 0, 'remaining': previous}
                changed = True
        elif mode in ('pause', 'coupure'):
            # Manual pauses survive a restart, external ON and reconnection.
            if power or timer:
                self.cleanup_off()
                power, timer = False, 0
        elif power and timer > 0:
            # Adopt an existing native timer without touching DP1 or DP9.
            self.s = {'mode': 'actif', 'deadline': self.now() + timer, 'remaining': timer}
            changed = True
        elif not power and timer > 0:
            self.call(self.d.set_timer, 0, dps_id=9)
            dps = self.read()
            if dps['9'] != 0 or dps['1']:
                raise RuntimeError('Minuteur OFF non annulé')
            timer = 0
        if changed:
            self.save()
        return {'power': power, 'nativeSeconds': timer, 'mode': self.s['mode'],
                'deadline': round(self.s['deadline'] * 1000), 'remaining': self.left(),
                'seenAt': round(self.now() * 1000), 'online': True}

    def confirm_timer(self, maximum):
        for attempt in range(5):
            self.call(lambda: None)
            dps = self.read()
            if dps['1'] and 0 < dps['9'] <= maximum:
                return dps
            if attempt < 4:
                self.sleep(.15)
        raise RuntimeError('Minuteur ou allumage non confirmé')

    def freeze_unreachable(self):
        # An unreachable plug is NOT evidence of a power cut. Native DP9 and
        # the software deadline continue. No OFF and no credit change here.
        return self.left()

    def deferred_pause(self, remaining):
        if type(remaining) is not int or not 0 < remaining <= 86400:
            raise ValueError('Temps de pause invalide')
        # Durable requested credit before any I/O. Repeated OFF is idempotent;
        # never send ON, including after a crash between OFF and publication.
        self.s = {'mode': 'pause', 'deadline': 0, 'remaining': remaining}
        self.save()
        self.cleanup_off()
        return self.observe()

    def execute(self, command, owner_uid):
        validate_pilotage(command, owner_uid, self.now() * 1000)
        self.expiry = command['expiresAt']
        action, amount = command['action'], command['seconds']
        saved_seconds = None
        programmed = False
        try:
            before = self.observe()
            mode = self.s['mode']
            if action == 'save':
                saved_seconds = min(before['nativeSeconds'], self.left()) if mode == 'actif' else self.left()
                if saved_seconds <= 0:
                    raise RuntimeError('Aucun temps à sauvegarder')
                self.s = {'mode': 'pause', 'deadline': 0, 'remaining': saved_seconds}
                self.save()
                self.call(self.d.turn_off)
                self.call(self.d.set_timer, 0, dps_id=9)
                after = self.read()
                if after['1'] or after['9'] != 0:
                    raise RuntimeError('Extinction non confirmée')
            elif action in ('off', 'pause'):
                if action == 'pause' and mode != 'actif':
                    raise RuntimeError('Aucun minuteur actif à mettre en pause')
                remaining = min(before['nativeSeconds'], self.left()) if action == 'pause' else 0
                self.s = {'mode': 'pause' if action == 'pause' else 'libre',
                          'deadline': 0, 'remaining': remaining}
                self.save()  # Durable credit before touching a socket.
                self.call(self.d.turn_off)
                self.call(self.d.set_timer, 0, dps_id=9)
                after = self.read()
                if after['1'] or after['9'] != 0:
                    raise RuntimeError('Extinction non confirmée')
            elif action == 'subtract':
                if mode not in ('actif', 'pause', 'coupure'):
                    raise RuntimeError('Aucun minuteur à diminuer')
                # Use confirmed native seconds while active; never increase credit.
                credit = min(before['nativeSeconds'], self.left()) if mode == 'actif' else self.left()
                remaining = max(0, credit - amount)
                if remaining == 0:
                    self.s = {'mode': 'termine', 'deadline': 0, 'remaining': 0}
                    self.save()
                    self.call(self.d.turn_off)
                    self.call(self.d.set_timer, 0, dps_id=9)
                    after = self.read()
                    if after['1'] or after['9'] != 0:
                        raise RuntimeError('Extinction non confirmée')
                elif mode in ('pause', 'coupure'):
                    self.s['remaining'] = remaining
                else:
                    # Persist the reduced credit before I/O; on any failure the
                    # existing programmed cleanup preserves only reduced credit.
                    self.s = {'mode': 'actif', 'deadline': self.now()+remaining, 'remaining': remaining}
                    self.save()
                    programmed = True
                    self.call(self.d.set_timer, remaining, dps_id=9)
                    after = self.confirm_timer(remaining)
                    self.s = {'mode': 'actif', 'deadline': min(self.s['deadline'], self.now()+after['9']), 'remaining': after['9']}
            elif action == 'on':
                self.call(self.d.set_timer, 0, dps_id=9)
                if self.read()['9'] != 0:
                    raise RuntimeError('Annulation du minuteur non confirmée')
                self.call(self.d.turn_on)
                after = self.read()
                if not after['1'] or after['9'] != 0:
                    raise RuntimeError('Allumage non confirmé')
                self.s = {'mode': 'libre', 'deadline': 0, 'remaining': 0}
            else:
                if action == 'start' and mode in ('actif', 'pause', 'coupure') and self.left() > 0:
                    raise RuntimeError('Minuteur déjà présent ; utiliser +Temps ou OFF')
                if action == 'resume' and mode not in ('pause', 'coupure'):
                    raise RuntimeError('Aucune pause à reprendre')
                if action == 'add' and mode not in ('actif', 'pause', 'coupure'):
                    raise RuntimeError('Aucun minuteur à prolonger')
                seconds = amount if action == 'start' else self.left() + (amount if action == 'add' else 0)
                if not 1 <= seconds <= 86400:
                    raise RuntimeError('Durée hors limite (maximum 24 heures)')
                if action == 'add' and mode in ('pause', 'coupure'):
                    self.s['remaining'] = seconds
                    self.save()
                    return self.observe()
                self.call(self.d.set_timer, seconds, dps_id=9)
                programmed = True
                armed = self.read()
                if not 0 < armed['9'] <= seconds:
                    raise RuntimeError('Minuteur non confirmé ; aucun allumage envoyé')
                budget_deadline = self.now() + seconds
                if action != 'add' and not armed['1']:
                    self.call(self.d.turn_on)
                # Some firmwares clear DP9 on OFF -> ON. Confirm fresh readings,
                # and repair DP9 once, without repeating ON or granting time.
                repaired = False
                after = None
                for attempt in range(5):
                    self.call(lambda: None)  # cancellation/expiry check before I/O
                    after = self.read()
                    if after['1'] and 0 < after['9'] <= seconds:
                        break
                    if after['1'] and after['9'] == 0 and not repaired:
                        remaining = min(seconds, math.floor(budget_deadline - self.now()))
                        if remaining < 1:
                            raise RuntimeError('Minuteur ou allumage non confirmé')
                        repaired = True
                        self.call(self.d.set_timer, remaining, dps_id=9)
                    if attempt < 4:
                        self.sleep(.2)
                else:
                    raise RuntimeError('Minuteur ou allumage non confirmé')
                self.s = {'mode': 'actif', 'deadline': self.now() + after['9'], 'remaining': after['9']}
            self.save()
            result = self.observe()
            if saved_seconds is not None:
                result['savedSeconds'] = saved_seconds
            return result
        except Exception:
            if programmed:
                credit = self.left()
                self.s = {'mode': 'coupure', 'deadline': 0, 'remaining': credit}
                self.save()
                try:
                    self.cleanup_off()
                except Exception:
                    pass
            raise
        finally:
            self.expiry = None


class Journal:
    """At most one attempt per command, persisted BEFORE any physical effect."""
    def __init__(self, path, seed=None, clock=time.time):
        self.path, self.clock = Path(path), clock
        self.lock = threading.Lock()
        self.data = load(self.path, None)
        if self.data is None:
            self.data = copy.deepcopy(seed or {'sessions': {}, 'processed': {}, 'results': {}})
        self.data.setdefault('sessions', {})
        self.data.setdefault('processed', {})
        self.data.setdefault('results', {})

    def write(self):
        save(self.path, self.data)

    def begin(self, poste, command):
        cid = command['id']
        with self.lock:
            if cid in self.data['processed']:
                return False
            self.data['processed'][cid] = int(self.clock())
            self.data['results'][poste] = {'id': cid, 'ok': False,
                'message': 'Commande interrompue ; vérifier la prise avant de relancer',
                'at': round(self.clock() * 1000)}
            cutoff = self.clock() - 86400
            self.data['processed'] = {k: v for k, v in self.data['processed'].items() if v >= cutoff}
            self.write()
            return True

    def session(self, poste, row):
        with self.lock:
            self.data['sessions'][poste] = copy.deepcopy(row)
            self.write()

    def result(self, poste, cid, ok, message, saved_seconds=None):
        with self.lock:
            self.data['results'][poste] = {'id': cid, 'ok': bool(ok), 'message': message,
                                         'at': round(self.clock() * 1000)}
            if saved_seconds is not None:
                self.data['results'][poste]['savedSeconds'] = saved_seconds
            self.write()

    def complete_saved(self, poste, cid, credit):
        with self.lock:
            free = {'mode':'libre','deadline':0,'remaining':0}
            self.data['sessions'][poste] = free
            self.data['results'][poste] = {'id':cid,'ok':True,'savedSeconds':credit,
                'message':'Temps sauvegardé et extinction confirmés','at':round(self.clock()*1000)}
            self.write()
            return copy.deepcopy(free)

    def receipt(self, poste):
        with self.lock:
            return copy.deepcopy(self.data['results'].get(poste))



