"""Android pilotage loop: parallel local plugs, one outbound Firebase channel."""
import copy
import contextlib
import io
import json
import queue
import threading
import time
import re
from urllib.parse import unquote
from pathlib import Path
from pilotage_core import Controller, Journal, validate_pilotage, validate_session
from firebase_transport import FirebaseTransport
from room_identity import runtime_config
import relay_core
def business_post(label):
    match = re.fullmatch(r'Poste\s+([1-7])(?:\s.*)?', str(label), re.I)
    return match.group(1) if match else ''


def persist_refresh(bridge, config, value):
    bridge.persist_refresh(value)
    config['refreshToken'] = value


class PilotageRunner:
    def __init__(self, directory, config, bridge, session, factory=None):
        config = runtime_config(config)
        self.root, self.config, self.bridge = Path(directory), config, bridge
        self.transport = FirebaseTransport(config['url'], config.get('idToken', ''), session,
            room=config['room'], refresh_token=config.get('refreshToken'), api_key=config.get('apiKey'),
            relay_uid=config.get('relayUid'), protocol='pilotage_v1', agent=config['agent'],
            on_refresh=lambda value: persist_refresh(bridge, config, value))
        seed = config.get('migrationState') or {'sessions': {}, 'processed': {}, 'results': {}}
        self.journal = Journal(self.root / 'pilotage_state.json', seed=seed, clock=self.transport.now)
        self.controllers, self.queues, self.threads = {}, {}, []
        self.device_locks = {}
        self.lock, self.stopped, self.active = threading.Lock(), threading.Event(), threading.Event()
        self.queued, self.status, self.ip_updates = set(), {}, {}
        self.local_safety = threading.Event()
        self.auto_pause_sent = {}
        self.next_auto_pause = 0
        self.revision, self.published = {}, {}
        self.last_report, self.last_message = 0, None
        self.discovery_next, self.discovery_thread = 0, None
        if factory is None:
            import tinytuya
            factory = tinytuya.OutletDevice
        for poste, did in config['postes'].items():
            row = config['devices'][did]
            plug = factory(did, row['ip'], row['key'], version=row['version'])
            plug.set_socketTimeout(2)
            plug.set_socketRetryLimit(1)
            plug.set_socketPersistent(False)
            self.controllers[poste] = Controller(plug, self.journal.data['sessions'].get(poste),
                now=self.transport.now, persist=lambda state, p=poste: self.journal.session(p, state),
                cancelled=lambda: self.stopped.is_set() or not self.local_safety.is_set() or bridge.shouldStop())
            self.queues[poste] = queue.Queue(maxsize=8)
            self.device_locks[poste] = threading.RLock()

    def locked_device(self, poste, fn):
        with self.device_locks[poste]:
            return fn()

    def sync_pause_requests(self):
        requests = self.transport.request('GET', 'pause_requests', business=True).json() or {}
        for key, intent in requests.items():
            if not isinstance(intent, dict):
                continue
            business = self.transport.request('GET', 'active_by_poste/' + key, business=True).json() or {}
            if (not business.get('actif') or business.get('sessionId') != intent.get('sessionId')
                or business.get('pendingPauseId') != intent.get('id')):
                continue
            result = self.transport.request('GET', 'pause_results/' + key, business=True).json() or {}
            if result.get('id') == intent.get('id') and result.get('powerConfirmed') is True:
                continue
            self.command_author({'by': intent.get('by')})
            poste = business_post(unquote(key))
            if poste not in self.controllers:
                continue
            def apply():
                # Reread while holding the physical device lock. A changed
                # session, role or native receipt invalidates this request.
                latest = self.transport.request('GET', 'active_by_poste/' + key, business=True).json() or {}
                if latest.get('sessionId') != intent.get('sessionId') or latest.get('pendingPauseId') != intent.get('id'):
                    return
                self.command_author({'by': intent.get('by')})
                receipt = self.journal.receipt(poste) or {}
                if intent.get('nativeId') and receipt.get('id') != intent['nativeId']:
                    return  # A newer physical command needs manual review.
                remaining = latest.get('pauseRemainingSec')
                if type(remaining) is not int or remaining != intent.get('remaining') or not 0 < remaining <= 86400:
                    return
                try:
                    state = self.controllers[poste].deferred_pause(remaining)
                except Exception:
                    self.update_status(poste, self.offline(poste))
                    return  # Keep request and retry after reconnection.
                self.update_status(poste, state)
                self.transport.request('PUT', 'pause_results/' + key, business=True, data={
                    'id': intent['id'], 'sessionId': intent['sessionId'], 'remaining': remaining,
                    'powerConfirmed': True, 'at': round(self.transport.now()*1000)})
            self.locked_device(poste, apply)

    def report(self, message):
        now = time.monotonic()
        if message == self.last_message and now - self.last_report < 30:
            return
        self.last_message, self.last_report = message, now
        self.bridge.report(message)
        path = self.root / 'diagnostic.log'
        if path.exists() and path.stat().st_size > 262144:
            path.replace(path.with_suffix('.ancien'))
        with path.open('a', encoding='utf-8') as out:
            out.write(time.strftime('%H:%M:%S ') + message + '\n')

    def restore_remote(self, rows):
        # Fresh installation can restore a pause/receipt even without an export.
        # Active native countdowns are read from the plugs, never reprogrammed.
        with self.journal.lock:
            for poste, row in rows.items():
                if poste not in self.controllers or not isinstance(row, dict):
                    continue
                if poste not in self.journal.data['sessions'] and row.get('mode') in ('pause', 'coupure'):
                    candidate = {'mode': row['mode'], 'deadline': 0, 'remaining': row.get('remaining', 0)}
                    try:
                        state = validate_session(candidate)
                    except ValueError:
                        continue
                    self.controllers[poste].s = state
                    self.journal.data['sessions'][poste] = copy.deepcopy(state)
                receipt = row.get('result')
                if isinstance(receipt, dict) and isinstance(receipt.get('id'), str):
                    self.journal.data['processed'][receipt['id']] = int(self.transport.now())
                    self.journal.data['results'].setdefault(poste, copy.deepcopy(receipt))
            self.journal.write()

    def command_author(self, command):
        author = command.get('by') if isinstance(command, dict) else None
        if author == self.config['ownerUid']:
            return author
        if not isinstance(author, str) or not author.isalnum() or len(author) > 128:
            raise ValueError('Auteur non autorisé')
        # Check revocation both before enqueue and immediately before execution.
        role = self.transport.request('GET', 'access/' + author + '/rooms/gz_YOUSSEF').json()
        if role != 'gerant':
            raise ValueError('Auteur non autorisé')
        return author

    def submit(self, poste, command):
        if poste not in self.queues or not self.active.is_set():
            return False
        author = self.command_author(command)
        try:
            validated = validate_pilotage(command, author, self.transport.now() * 1000)
        except ValueError as error:
            cid = command.get('id') if isinstance(command, dict) else None
            if isinstance(cid, str) and 16 <= len(cid) <= 80:
                with self.journal.lock:
                    seen = cid in self.journal.data['processed']
                if not seen and self.journal.begin(poste, command):
                    reasons = {'Commande expirée', 'Dates invalides', 'Action inconnue',
                               'Durée invalide', 'Durée requise', 'Identifiant de commande invalide'}
                    message = str(error) if str(error) in reasons else 'Commande invalide'
                    self.journal.result(poste, cid, False, message)
                    with self.lock:
                        row = copy.deepcopy(self.status.get(poste, {'online': False,
                            'mode': 'libre', 'seenAt': round(self.transport.now()*1000)}))
                    self.update_status(poste, row)
            return False
        if validated['action'] in ('on', 'off') and author != self.config['ownerUid']:
            raise ValueError('OFF TV réservé au Patron')
        cid = validated['id']
        with self.lock:
            with self.journal.lock:
                processed = cid in self.journal.data['processed']
            if processed or cid in self.queued:
                return False
            try:
                self.queues[poste].put_nowait(validated)
            except queue.Full:
                return False
            self.queued.add(cid)
        return True

    def update_status(self, poste, row):
        result = self.journal.receipt(poste)
        if result:
            row['result'] = result
        with self.lock:
            self.status[poste] = copy.deepcopy(row)
            self.revision[poste] = self.revision.get(poste, 0) + 1

    def process(self, poste, command):
        """One physical attempt; a lost network response cannot repeat +Temps."""
        ctrl = self.controllers[poste]
        author = self.command_author(command)
        validate_pilotage(command, author, self.transport.now() * 1000)
        if command['action'] in ('on', 'off') and author != self.config['ownerUid']:
            raise ValueError('OFF TV réservé au Patron')
        if not self.active.is_set() or self.stopped.is_set() or self.bridge.shouldStop():
            return False
        if not self.journal.begin(poste, command):
            return False
        try:
            state = ctrl.execute(command, self.command_author(command))
            if command['action'] == 'save':
                credit = state.pop('savedSeconds')
                ctrl.s = self.journal.complete_saved(poste, command['id'], credit)
                state.update(mode='libre', remaining=0, deadline=0)
            else:
                self.journal.result(poste, command['id'], True, 'État confirmé par la prise')
        except Exception as error:
            # Only our own fixed errors may be published. Vendor replies contain
            # no useful user-facing details and can include device identifiers.
            allowed = {'État de la prise non confirmé','Minuteur natif non confirmé','Relais arrêté',
                'Commande expirée avant confirmation','La prise a refusé la commande',
                'Extinction non confirmée','Interruption non confirmée','Minuteur OFF non annulé',
                'Aucun minuteur actif à mettre en pause','Annulation du minuteur non confirmée',
                'Allumage non confirmé','Minuteur déjà présent ; utiliser +Temps ou OFF',
                'Aucune pause à reprendre','Aucun minuteur à prolonger','Aucun minuteur à diminuer',
                'Durée hors limite (maximum 24 heures)',
                'Minuteur non confirmé ; aucun allumage envoyé','Minuteur ou allumage non confirmé'}
            message = str(error) if type(error) in (ValueError, RuntimeError) and str(error) in allowed else 'Prise indisponible'
            self.journal.result(poste, command['id'], False, message)
            try:
                state = ctrl.observe()
            except Exception:
                state = self.offline(poste)
        self.update_status(poste, state)
        return True

    def offline(self, poste):
        ctrl = self.controllers[poste]
        ctrl.freeze_unreachable()
        return {'online': False, 'seenAt': round(self.transport.now() * 1000),
                'mode': ctrl.s['mode'], 'remaining': ctrl.left(), 'deadline': round(ctrl.s['deadline'] * 1000)}

    def worker(self, poste):
        ctrl, next_observe = self.controllers[poste], 0
        try:
            while not self.stopped.is_set() and not self.bridge.shouldStop():
                if not self.active.is_set():
                    # Observe only an already-owned local lease. No queued
                    # remote command is consumed while Firebase is unreachable.
                    if self.local_safety.is_set() and time.monotonic() >= next_observe:
                        try:
                            self.locked_device(poste, lambda: self.update_status(poste, ctrl.observe()))
                        except Exception:
                            self.update_status(poste, self.offline(poste))
                        next_observe = time.monotonic() + 2
                    self.stopped.wait(.2)
                    continue
                with self.lock:
                    ip = self.ip_updates.pop(poste, None)
                if ip:
                    ctrl.d.close()
                    ctrl.d.address = ip
                    next_observe = 0
                try:
                    command = self.queues[poste].get(timeout=.2)
                except queue.Empty:
                    command = None
                if command:
                    try:
                        self.locked_device(poste, lambda: self.process(poste, command))
                    except ValueError:
                        pass  # Expired while waiting: no socket mutation.
                    finally:
                        with self.lock:
                            self.queued.discard(command['id'])
                        self.queues[poste].task_done()
                    next_observe = time.monotonic() + 5
                elif time.monotonic() >= next_observe:
                    try:
                        self.locked_device(poste, lambda: self.update_status(poste, ctrl.observe()))
                    except Exception:
                        self.update_status(poste, self.offline(poste))
                    next_observe = time.monotonic() + 5
        finally:
            ctrl.d.close()

    def discover(self):
        try:
            import tinytuya
            with contextlib.redirect_stdout(io.StringIO()):
                rows = tinytuya.deviceScan(verbose=False, maxretry=12, poll=False)
            addresses = relay_core.discovered_addresses(rows, set(self.config['devices']))
            with self.lock:
                for poste, did in self.config['postes'].items():
                    if did in addresses and addresses[did] != self.config['devices'][did]['ip']:
                        self.config['devices'][did]['ip'] = addresses[did]
                        self.ip_updates[poste] = addresses[did]
        except Exception:
            pass

    def publish(self):
        with self.lock:
            revisions = dict(self.revision)
            pending = {p: copy.deepcopy(s) for p, s in self.status.items()
                       if revisions[p] != self.published.get(p)}
        if pending:
            # One atomic multi-poste write, compatible with per-poste RTDB rules.
            self.transport.request('PATCH', 'states', data=pending)
            self.published.update({p: revisions[p] for p in pending})

    def sync_auto_pauses(self):
        with self.lock:
            rows = copy.deepcopy(self.status)
        candidates = {p: s for p, s in rows.items()
                      if s.get('mode') == 'coupure' and s.get('remaining', 0) > 0}
        if not candidates:
            return
        active = self.transport.request('GET', 'active_by_poste', business=True).json() or {}
        for key, business in active.items():
            if not isinstance(business, dict) or not business.get('actif') or not business.get('sessionId'):
                continue
            poste = business_post(unquote(key))
            if poste not in self.controllers:
                continue
            state = candidates.get(poste)
            if not state:
                continue
            receipt = state.get('result') or self.journal.receipt(poste) or {}
            native_id = receipt.get('id', '')
            if business.get('nativeCommandId') and business['nativeCommandId'] != native_id:
                continue  # Old observation cannot freeze a newly resumed session.
            marker = {'sessionId': business['sessionId'], 'nativeId': native_id,
                      'remaining': min(86400, max(0, int(state['remaining']))),
                      'at': state.get('seenAt', round(self.transport.now()*1000)),
                      'powerConfirmed': state.get('online') is True and state.get('power') is False,
                      'reason': 'prise_eteinte' if state.get('online') else 'prise_injoignable'}
            signature = (marker['sessionId'], marker['nativeId'], marker['remaining'],
                         marker['powerConfirmed'], marker['reason'])
            if self.auto_pause_sent.get(key) == signature:
                continue
            self.transport.request('PUT', 'auto_pauses/' + key, data=marker, business=True)
            self.auto_pause_sent[key] = signature

    def sync_business(self):
        from business import apply_confirmed, shift
        with self.lock:
            signature = (shift(round(self.transport.now()*1000))[0], tuple(sorted((p,s.get('mode'),s.get('power'),(s.get('result') or {}).get('id')) for p,s in self.status.items())))
        if signature == getattr(self, 'business_signature', None):
            return
        from firebase_transport import FirebaseConflict
        import uuid
        key = str(uuid.uuid4())
        path = 'operation_lock'
        response = self.transport.request('GET', path, headers={'X-Firebase-ETag': 'true'}, business=True)
        current = response.json() or {}
        if current.get('until', 0) >= self.transport.now()*1000:
            return
        if not response.headers.get('ETag'):
            raise OSError('Verrou sans ETag')
        try:
            self.transport.request('PUT', path, data={'id':key,'by':self.config['relayUid'],
                'until':round(self.transport.now()*1000)+90000}, headers={'if-match':response.headers['ETag']}, business=True)
        except FirebaseConflict:
            return
        try:
            response = self.transport.request('GET', '', headers={'X-Firebase-ETag':'true'}, business=True)
            old = response.json() or {}
            with self.lock:
                states = copy.deepcopy(self.status)
            new = apply_confirmed(old, states, round(self.transport.now()*1000))
            if old != new:
                if not response.headers.get('ETag'):
                    raise OSError('Salle sans ETag')
                def leaves(a,b,prefix=''):
                    out={}
                    for k in set(a)|set(b):
                        if not prefix and k=='operation_lock':continue
                        path=prefix+'/'+k if prefix else k
                        if a.get(k)==b.get(k):continue
                        if isinstance(a.get(k),dict) and isinstance(b.get(k),dict):out.update(leaves(a[k],b[k],path))
                        else:out[path]=b.get(k)
                    return out
                patch = leaves(old,new)
                self.transport.request('PATCH', '', data=patch, business=True)
            self.business_signature = signature
        finally:
            response = self.transport.request('GET', path, headers={'X-Firebase-ETag':'true'}, business=True)
            if (response.json() or {}).get('id') == key and response.headers.get('ETag'):
                self.transport.request('DELETE', path, headers={'if-match':response.headers['ETag']}, business=True)

    def snapshot(self):
        with self.lock:
            states = copy.deepcopy(self.status)
        display = []
        for poste, did in sorted(self.config['postes'].items(), key=lambda item: int(item[0])):
            state = states.get(poste, {})
            display.append({'poste': int(poste), 'ip': self.config['devices'][did]['ip'],
                'etat': ('ON' if state.get('power') else 'OFF') if state.get('online') else 'Non confirmé',
                'secondes': state.get('nativeSeconds')})
        self.bridge.snapshot(json.dumps(display))

    def run(self):
        bootstrapped, next_heartbeat, next_display = False, 0, 0
        try:
            while not self.stopped.is_set() and not self.bridge.shouldStop():
                try:
                    now = time.monotonic()
                    if now >= next_heartbeat or not self.active.is_set():
                        if not self.transport.heartbeat():
                            self.local_safety.clear()
                            self.active.clear()
                            self.report('Autre relais actif : arrêter Termux et attendre 60 secondes')
                            self.stopped.wait(2)
                            continue
                        if not bootstrapped:
                            self.restore_remote(self.transport.states())
                            bootstrapped = True
                            for poste in self.controllers:
                                worker = threading.Thread(target=self.worker, args=(poste,), daemon=True)
                                worker.start()
                                self.threads.append(worker)
                        self.local_safety.set()
                        self.active.set()
                        next_heartbeat = time.monotonic() + 8
                    for poste, command in self.transport.pending().items():
                        try:
                            self.submit(poste, command)
                        except ValueError:
                            self.report('Commande poste ' + str(poste) + ' refusée : compte non autorisé')
                    self.publish()
                    if time.monotonic() >= self.next_auto_pause:
                        try:
                            self.sync_pause_requests()
                            self.sync_auto_pauses()
                            self.sync_business()
                        except Exception:
                            self.report('Pause locale conservée — synchronisation GameZone à réessayer')
                        self.next_auto_pause = time.monotonic() + 2
                    self.report('YOUSSEF — relais Firebase actif v1.1 (' + str(len(self.controllers)) + ' postes)')
                except PermissionError:
                    self.local_safety.clear()
                    self.active.clear()
                    self.report('Firebase : connexion du compte relais ou règles à vérifier')
                    self.stopped.wait(3)
                except Exception:
                    # No command accepted after losing the server. Native timers
                    # continue; local observation resumes after lease renewal.
                    self.active.clear()
                    self.report('Firebase inaccessible — minuteurs natifs conservés')
                    self.stopped.wait(1)
                now = time.monotonic()
                if now >= next_display or self.bridge.shouldCheck():
                    self.snapshot()
                    next_display = now + 2
                if now >= self.discovery_next and self.active.is_set() and (self.discovery_thread is None or not self.discovery_thread.is_alive()):
                    self.discovery_thread = threading.Thread(target=self.discover, daemon=True)
                    self.discovery_thread.start()
                    self.discovery_next = now + 60
                self.stopped.wait(.5)
        finally:
            self.stopped.set()
            self.local_safety.clear()
            self.active.clear()
            for worker in self.threads:
                worker.join()  # Bounded local calls; no second controller during shutdown.
            self.report('Relais YOUSSEF arrêté ; minuteurs natifs conservés')


