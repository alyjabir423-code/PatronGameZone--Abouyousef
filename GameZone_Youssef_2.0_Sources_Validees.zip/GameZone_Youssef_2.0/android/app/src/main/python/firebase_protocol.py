"""Prototype hors production: validation stricte des commandes YOUSSEF Firebase -> Oppo.
Ne se connecte pas à Firebase et ne commande aucune prise directement.
"""
import time
import uuid

OPS = {'power', 'status', 'timers'}

def prepare_command(op, devices, now_ms=None, ttl_ms=15000):
    now_ms = int(time.time()*1000) if now_ms is None else int(now_ms)
    if op not in OPS: raise ValueError('Operation non autorisee')
    if not isinstance(devices, list) or not 1 <= len(devices) <= 256: raise ValueError('Nombre de prises invalide')
    if ttl_ms < 1000 or ttl_ms > 30000: raise ValueError('TTL invalide')
    return {'id': str(uuid.uuid4()), 'op':op, 'devices':devices,
            'createdAt':now_ms, 'expiresAt':now_ms+ttl_ms, 'status':'pending'}

def validate_for_relay(command, allowed_ids, now_ms, processed_ids):
    if not isinstance(command,dict) or command.get('status') != 'pending': raise ValueError('Statut invalide')
    cid=command.get('id')
    if not isinstance(cid,str) or len(cid)>80 or cid in processed_ids: raise ValueError('ID invalide ou deja execute')
    if command.get('op') not in OPS: raise ValueError('Operation invalide')
    created,expiry=command.get('createdAt'),command.get('expiresAt')
    if type(created) is not int or type(expiry) is not int or not created <= now_ms < expiry or expiry-created > 30000:
        raise ValueError('Commande expiree ou horodatage invalide')
    devices=command.get('devices')
    if not isinstance(devices,list) or not 1<=len(devices)<=256: raise ValueError('Cibles invalides')
    ids=[x.get('devid') for x in devices if isinstance(x,dict)]
    if len(ids)!=len(devices) or len(ids)!=len(set(ids)) or not set(ids).issubset(set(allowed_ids)):
        raise ValueError('Prise inconnue ou dupliquee')
    if command['op']=='power' and any(type(x.get('turnOn')) is not bool for x in devices):
        raise ValueError('Etat electrique invalide')
    return {k:command[k] for k in ('id','op','devices','createdAt','expiresAt')}

