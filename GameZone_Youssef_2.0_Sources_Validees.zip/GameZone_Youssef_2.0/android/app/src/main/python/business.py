"""Idempotent business projection from confirmed local observations. No socket I/O."""
import copy
import datetime
import math
import re
from urllib.parse import unquote

SHIFT_SECONDS = 8 * 3600  # Matches the current CP1 reference; do not change tariffs.

def shift(now_ms):
    start = math.floor((now_ms/1000-SHIFT_SECONDS)/86400)*86400+SHIFT_SECONDS
    date = datetime.datetime.fromtimestamp(start, datetime.timezone.utc)
    return date.strftime('%Y-%m-%d'), start*1000, date.strftime('%a %b %d %Y')

def apply_confirmed(root, states, now_ms):
    before = root or {}
    root = copy.deepcopy(before)
    if not isinstance(root.get('postes'), list):
        return root
    day, day_start, date = shift(now_ms)
    old_sessions = root.get('sessions') or {}
    if old_sessions.get('dayStart') is None and old_sessions.get('date') == date:
        root['sessions']['dayStart'] = day_start
        root.setdefault('daily', {}).setdefault(day, copy.deepcopy(root['sessions']))
    elif old_sessions.get('dayStart') != day_start:
        # Old data without an epoch marker is archived intact before reset.
        root.setdefault('rollover_archives', {}).setdefault(str(int(day_start)), copy.deepcopy(old_sessions))
        root['sessions'] = dict(recettes=0,count=0,date=date,parPoste={},sessionsParPoste={},payStats={},dayStart=day_start)
        root.setdefault('daily', {}).setdefault(day, copy.deepcopy(root['sessions']))
        root['current_day'] = dict(key=day, dayStart=day_start)
        for row in (root.get('active_by_poste') or {}).values():
            if isinstance(row, dict) and row.get('actif'):
                row['montantJourSession'] = 0
        for row in root.get('active_postes') or []:
            if isinstance(row, dict) and row.get('actif'):
                row['montantJourSession'] = 0
    root['current_day'] = dict(key=day, dayStart=day_start)
    for index, p in enumerate(root['postes']):
        if not isinstance(p, dict): continue
        label = str(p.get('num',''))
        m = re.fullmatch(r'Poste\s+([1-7])(?:\s.*)?', label, re.I)
        if not m: continue
        key = next((k for k in (root.get('active_by_poste') or {}) if unquote(k)==label), None)
        a = root.get('active_by_poste',{}).get(key) if key else None
        s = states.get(m.group(1)) or {}
        if not isinstance(a,dict) or not a.get('actif') or not a.get('sessionId'): continue
        sid = a['sessionId']
        receipt = s.get('result') or {}
        if (s.get('online') is not True or s.get('power') is not False or s.get('mode')!='termine'
                or s.get('nativeSeconds')!=0 or s.get('remaining')!=0
                or not 0 <= now_ms-s.get('seenAt',0) <= 15000
                or s.get('seenAt',0)<a.get('startedAt',0)
                or a.get('nativeCommandId') and receipt.get('id')!=a['nativeCommandId']):
            continue
        closed = root.setdefault('closed_sessions',{})
        if sid not in closed:
            bonus = bool(a.get('bonusOnly'))
            closed[sid] = dict(status='bonus_termine' if bonus else 'terminee_auto',ts=now_ms,dateKey=day,poste=label)
            root.setdefault('activity_daily',{}).setdefault(day,{})['end-'+sid] = dict(
                ts=now_ms,dateKey=day,poste=label,sessionId=sid,typeActivite='terminee_auto',
                main=label+' — Temps écoulé',detail='Fin automatique confirmée par la prise',
                montant=a.get('montantSession',0),tempsRestantSec=0,actorRole='relais',color='b')
            if not bonus:
                ss=root['sessions'];ss['count']=max(0,ss.get('count',0))+1
                daily=root.setdefault('daily',{}).setdefault(day,copy.deepcopy(ss))
                daily['count']=ss['count']
        a.update(actif=False,starting=False,cleanup=False,paused=False,finTs=0,pauseRemainingSec=0,updatedAt=now_ms)
        rows=root.get('active_postes')
        if isinstance(rows,list) and index<len(rows): rows[index]=copy.deepcopy(a)
    if root!=before:
        root['businessRevision']=max(0,root.get('businessRevision',0))+1
    return root
