package ci.gamezone.relais;
import android.app.*;
import android.content.*;
import android.os.*;
import android.net.*;
import android.net.wifi.WifiManager;
import com.chaquo.python.*;
import com.chaquo.python.android.AndroidPlatform;
import java.util.concurrent.atomic.AtomicBoolean;

public class RelayService extends Service {
 public static volatile String status="Relais arrêté";
 public static volatile long progress=0;
 public static volatile boolean running=false;
 public static volatile String devicesText="Vérification des prises en attente";
 public static final AtomicBoolean checkRequested=new AtomicBoolean(false);
 public boolean shouldCheck(){return checkRequested.getAndSet(false);}
 public void snapshot(String text){
  try{org.json.JSONArray rows=new org.json.JSONArray(text);StringBuilder out=new StringBuilder();
   for(int n=0;n<rows.length();n++){org.json.JSONObject row=rows.getJSONObject(n);out.append("Poste ").append(row.getInt("poste")).append(" · ").append(row.getString("etat")).append("\n").append(row.getString("ip"));
    if(!row.isNull("secondes"))out.append(" · ").append(row.getInt("secondes")).append(" s");out.append("\n\n");}
   devicesText=out.toString();
  }catch(Exception e){devicesText="Diagnostic local indisponible";}
 }
 private final AtomicBoolean stopped=new AtomicBoolean(false);
 private PowerManager.WakeLock wake;
 private WifiManager.WifiLock wifi;
 private WifiManager.MulticastLock multicast;
 private ConnectivityManager cm;
 private ConnectivityManager.NetworkCallback callback;
 private Thread worker;
 private Notification notification(String text) {
  Intent open=new Intent(this,MainActivity.class);
  PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
  return new Notification.Builder(this,"relay").setSmallIcon(android.R.drawable.stat_notify_sync).setContentTitle("GameZone — relais OPPO").setContentText(text).setContentIntent(pi).setOngoing(true).build();
 }
 public void persist_refresh(String value) {
  synchronized(Vault.class) {
   try {org.json.JSONObject config=new org.json.JSONObject(Vault.load(this));config.put("refreshToken",value);Vault.save(this,config.toString());}
   catch(Exception e){throw new IllegalStateException("Renouvellement Firebase non enregistré");}
  }
 }
 public void heartbeat(){progress=SystemClock.elapsedRealtime();}
 public void report(String text) {
  status=text; progress=SystemClock.elapsedRealtime();
  getSystemService(NotificationManager.class).notify(7,notification(text));
 }
 public boolean shouldStop(){return stopped.get();}
 @Override public void onCreate() {
  super.onCreate();
  getSystemService(NotificationManager.class).createNotificationChannel(new NotificationChannel("relay","Relais des prises",NotificationManager.IMPORTANCE_LOW));
  startForeground(7,notification("Démarrage du relais…"));
  wake=getSystemService(PowerManager.class).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"GameZone:relay");wake.setReferenceCounted(false);wake.acquire();
  wifi=((WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE)).createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF,"GameZone:wifi");wifi.setReferenceCounted(false);wifi.acquire();
  multicast=((WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE)).createMulticastLock("GameZone:discovery");multicast.setReferenceCounted(false);multicast.acquire();
  cm=getSystemService(ConnectivityManager.class);
  callback=new ConnectivityManager.NetworkCallback(){
   @Override public void onAvailable(Network n){report("Réseau détecté — connexion en cours");}
   @Override public void onLost(Network n){report("Réseau perdu — nouvelle tentative automatique");}
  };
  cm.registerDefaultNetworkCallback(callback);
 }
 @Override public int onStartCommand(Intent intent,int flags,int id) {
  if(!getSharedPreferences("relay",0).getBoolean("enabled",false)){stopSelf();return START_NOT_STICKY;}
  if(worker==null) {
   running=true;
   worker=new Thread(()->{
    synchronized(RelayService.class) {
     while(!stopped.get()) {
      try {
       running=true;
       if(!Python.isStarted())Python.start(new AndroidPlatform(this));
       Python.getInstance().getModule("engine").callAttr("run",getFilesDir().getAbsolutePath(),Vault.load(this),this);
      }catch(Exception e){report("Erreur du relais — nouvelle tentative dans 10 secondes");}
      if(!stopped.get()) {
       for(int n=0;n<100&&!stopped.get();n++) {
        try{Thread.sleep(100);}catch(InterruptedException e){Thread.currentThread().interrupt();return;}
       }
      }
     }
     running=false;
    }
   },"gamezone-relay");worker.start();
  }
  return START_STICKY;
 }
 @Override public void onDestroy(){
  stopped.set(true); // running stays true until the Python worker exits.
  if(cm!=null&&callback!=null)cm.unregisterNetworkCallback(callback);
  if(wifi!=null&&wifi.isHeld())wifi.release();
  if(multicast!=null&&multicast.isHeld())multicast.release();
  if(wake!=null&&wake.isHeld())wake.release();
  super.onDestroy();
  // Embedded Python cannot be interrupted safely in a socket call. The process
  // is not killed here; the engine checks shouldStop between bounded operations.
 }
 @Override public IBinder onBind(Intent i){return null;}
}


