package ci.gamezone.relais;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Encrypted private relay configuration; never export key material. */
public final class Vault {
 private static final String ALIAS = "gamezone_youssef_relay_config_v1";
 private static final String STORE = "AndroidKeyStore";
 private Vault() {}
 private static SecretKey key() throws Exception {
  KeyStore ks=KeyStore.getInstance(STORE);ks.load(null);
  if(ks.containsAlias(ALIAS))return ((KeyStore.SecretKeyEntry)ks.getEntry(ALIAS,null)).getSecretKey();
  KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,STORE);
  kg.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
   .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
   .setKeySize(256).build());
  return kg.generateKey();
 }
 public static void save(Context context,String text) throws Exception {
  if(text==null)throw new IllegalArgumentException("Configuration vide");
  Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());
  byte[] iv=c.getIV();byte[] encrypted=c.doFinal(text.getBytes(StandardCharsets.UTF_8));
  if(iv.length!=12)throw new IllegalStateException("IV invalide");
  File dir=context.getFilesDir();File tmp=new File(dir,"config.enc.tmp");
  try(FileOutputStream out=new FileOutputStream(tmp)) {
   out.write(new byte[]{'G','Z','V','1'});out.write(iv);out.write(encrypted);out.getFD().sync();
  }
  try {Files.move(tmp.toPath(),new File(dir,"config.enc").toPath(),StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}
  catch(java.nio.file.AtomicMoveNotSupportedException e){Files.move(tmp.toPath(),new File(dir,"config.enc").toPath(),StandardCopyOption.REPLACE_EXISTING);}
 }
 public static String load(Context context) throws Exception {
  File f=new File(context.getFilesDir(),"config.enc");
  if(!f.isFile()||f.length()<33||f.length()>1048576)throw new java.io.IOException("Configuration absente ou invalide");
  byte[] data=Files.readAllBytes(f.toPath());
  if(data[0]!='G'||data[1]!='Z'||data[2]!='V'||data[3]!='1')throw new java.io.IOException("Format non reconnu");
  byte[] iv=java.util.Arrays.copyOfRange(data,4,16);
  Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,iv));
  return new String(c.doFinal(data,16,data.length-16),StandardCharsets.UTF_8);
 }
}

