package ci.gamezone.relais;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.media.*;
import android.media.session.*;
import android.net.Uri;
import android.os.*;

/** Independent local audio: never starts, stops or writes relay state. */
public class MusicService extends Service {
 public static final String PLAY="youssef.music.PLAY", TOGGLE="youssef.music.TOGGLE", PAUSE="youssef.music.PAUSE";
 public static volatile boolean playing=false;
 public static volatile String status="Aucun son sélectionné";
 private static final int ID=2003;
 private MediaPlayer player;
 private MediaSession session;
 private AudioManager audio;
 private AudioFocusRequest focus;
 private boolean prepared=false, wantPlay=false;
 private final AudioAttributes attributes=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();
 private final BroadcastReceiver noisy=new BroadcastReceiver(){public void onReceive(Context c,Intent i){pause();}};
 @Override public void onCreate(){
  super.onCreate();
  audio=(AudioManager)getSystemService(AUDIO_SERVICE);
  focus=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN).setAudioAttributes(attributes).setWillPauseWhenDucked(true).setOnAudioFocusChangeListener(change->{if(change<0)pause();}).build();
  session=new MediaSession(this,"Youssef musique");
  session.setCallback(new MediaSession.Callback(){public void onPause(){pause();}public void onPlay(){resume();}public void onStop(){pause();}});
  session.setActive(true);
  getSystemService(NotificationManager.class).createNotificationChannel(new NotificationChannel("youssef_music","Musique GameZone",NotificationManager.IMPORTANCE_LOW));
  if(Build.VERSION.SDK_INT>=33)registerReceiver(noisy,new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY),Context.RECEIVER_NOT_EXPORTED);
  else registerReceiver(noisy,new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY));
 }
 private Notification notification(){
  PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
  PendingIntent toggle=PendingIntent.getService(this,1,new Intent(this,MusicService.class).setAction(TOGGLE),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
  return new Notification.Builder(this,"youssef_music").setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("GameZone — musique en boucle").setContentText(status).setContentIntent(open)
   .addAction(new Notification.Action.Builder(playing?android.R.drawable.ic_media_pause:android.R.drawable.ic_media_play,playing?"Pause":"Reprendre",toggle).build())
   .setStyle(new Notification.MediaStyle().setMediaSession(session.getSessionToken()).setShowActionsInCompactView(0)).setOngoing(playing).setOnlyAlertOnce(true).build();
 }
 private void foreground(){
  if(Build.VERSION.SDK_INT>=29)startForeground(ID,notification(),ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
  else startForeground(ID,notification());
 }
 private void publish(){
  session.setPlaybackState(new PlaybackState.Builder().setActions(PlaybackState.ACTION_PLAY|PlaybackState.ACTION_PAUSE|PlaybackState.ACTION_PLAY_PAUSE|PlaybackState.ACTION_STOP)
   .setState(playing?PlaybackState.STATE_PLAYING:PlaybackState.STATE_PAUSED,PlaybackState.PLAYBACK_POSITION_UNKNOWN,playing?1f:0f).build());
  getSystemService(NotificationManager.class).notify(ID,notification());
 }
 private void releasePlayer(){
  if(player!=null){player.release();player=null;}prepared=false;playing=false;
  audio.abandonAudioFocusRequest(focus);
 }
 private void load(Uri uri){
  wantPlay=true;releasePlayer();status="Chargement du son…";publish();
  try{
   MediaPlayer current=new MediaPlayer();player=current;
   current.setAudioAttributes(attributes);current.setWakeMode(this,PowerManager.PARTIAL_WAKE_LOCK);
   current.setDataSource(this,uri);current.setLooping(true);
   current.setOnPreparedListener(p->{if(player!=p)return;prepared=true;if(wantPlay)resume();else{status="Musique en pause";publish();}});
   current.setOnErrorListener((p,what,extra)->{if(player==p)fail();return true;});
   current.prepareAsync();
  }catch(Exception e){fail();}
 }
 private void fail(){wantPlay=false;releasePlayer();status="Son illisible : choisissez un autre fichier";publish();stopForeground(STOP_FOREGROUND_DETACH);stopSelf();}
 private void pause(){
  wantPlay=false;
  if(player!=null&&prepared){try{player.pause();}catch(IllegalStateException ignored){}}
  playing=false;audio.abandonAudioFocusRequest(focus);status="Musique en pause";publish();
  stopForeground(STOP_FOREGROUND_DETACH);
 }
 private void resume(){
  wantPlay=true;
  if(player==null){String saved=getSharedPreferences("music",0).getString("uri",null);if(saved==null){status="Choisissez d’abord un son";publish();stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();return;}load(Uri.parse(saved));return;}
  if(!prepared)return;
  foreground();
  if(audio.requestAudioFocus(focus)!=AudioManager.AUDIOFOCUS_REQUEST_GRANTED){wantPlay=false;playing=false;status="Audio occupé : appuyez sur Reprendre";publish();stopForeground(STOP_FOREGROUND_DETACH);return;}
  try{player.start();playing=true;status="Lecture en boucle";publish();}catch(IllegalStateException e){fail();}
 }
 @Override public int onStartCommand(Intent intent,int flags,int startId){
  foreground();
  if(intent==null){stopSelf();return START_NOT_STICKY;}
  String action=intent.getAction();
  if(PLAY.equals(action)&&intent.getData()!=null)load(intent.getData());
  else if(PAUSE.equals(action)||TOGGLE.equals(action)&&(playing||wantPlay))pause();
  else resume();
  return START_NOT_STICKY;
 }
 @Override public void onDestroy(){
  wantPlay=false;releasePlayer();status="Musique arrêtée";
  try{unregisterReceiver(noisy);}catch(IllegalArgumentException ignored){}
  session.release();getSystemService(NotificationManager.class).cancel(ID);super.onDestroy();
 }
 @Override public IBinder onBind(Intent intent){return null;}
}

