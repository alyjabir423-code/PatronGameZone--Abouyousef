package ci.gamezone.relais;
import android.content.*;
public class BootReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){
  if(i==null || (!Intent.ACTION_BOOT_COMPLETED.equals(i.getAction()) && !Intent.ACTION_MY_PACKAGE_REPLACED.equals(i.getAction())))return;
  if(c.getSharedPreferences("relay",0).getBoolean("enabled",false)) {
   try{c.startForegroundService(new Intent(c,RelayService.class));}
   catch(RuntimeException e){c.getSharedPreferences("relay",0).edit().putString("bootError","Démarrage refusé par Android : ouvrir GameZone Relais").apply();}
  }
 }
}

