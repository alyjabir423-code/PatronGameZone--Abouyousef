package ci.gamezone.relais;
import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.provider.Settings;
import android.widget.*;
import com.chaquo.python.*;
import com.chaquo.python.android.AndroidPlatform;
import java.io.*;
import java.util.zip.*;
import org.json.*;

public class MainActivity extends Activity {
 TextView state;
 TextView devices;
 Handler handler=new Handler();
 void message(String text){new AlertDialog.Builder(this).setMessage(text).setPositiveButton("OK",null).show();}
 void button(LinearLayout layout,String text,Runnable action){Button b=new Button(this);b.setText(text);b.setOnClickListener(v->action.run());layout.addView(b);}
 @Override public void onCreate(Bundle saved){
  super.onCreate(saved);
  LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(32,40,32,24);
  ScrollView scroll=new ScrollView(this);scroll.addView(box);setContentView(scroll);
  TextView title=new TextView(this);title.setText("GameZone Relais OPPO\nRelais Youssef 2.0 — sept prises");title.setTextSize(26);title.setTextColor(0xFF62E6C4);box.addView(title);
  box.setBackgroundColor(0xFF111827);
  state=new TextView(this);state.setTextSize(18);state.setTextColor(0xFFFFFFFF);state.setPadding(0,28,0,28);box.addView(state);
  TextView help=new TextView(this);help.setTextColor(0xFFCBD5E1);help.setText("Ce téléphone relie vos prises configurées à GameZone. Importez la configuration locale, puis démarrez le relais. Gardez le Wi-Fi de la salle et Internet disponibles.\n\nArrêtez l’ancien relais Youssef (application v09 ou Termux) avant de démarrer cette version 2.0. Conservez l’ancienne application. Les minuteurs déjà programmés dans les prises continuent.");box.addView(help);
  devices=new TextView(this);devices.setTextColor(0xFFFFFFFF);devices.setTextSize(17);devices.setPadding(0,24,0,12);box.addView(devices);
  button(box,"♫ Choisir un son — lecture en boucle",()->{
   Intent music=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("audio/*").addCategory(Intent.CATEGORY_OPENABLE);
   music.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
   startActivityForResult(music,42);
  });
  TextView musicInfo=new TextView(this);musicInfo.setTextColor(0xFFCBD5E1);box.addView(musicInfo);
  Button musicPause=new Button(this);box.addView(musicPause);
  musicPause.setOnClickListener(v->{try{startForegroundService(new Intent(this,MusicService.class).setAction(MusicService.TOGGLE));}catch(RuntimeException e){message("Lecture indisponible. Choisissez à nouveau un son.");}});
  handler.post(new Runnable(){public void run(){musicInfo.setText(MusicService.status);musicPause.setText(MusicService.playing?"⏸ Pause musique":"▶ Reprendre la musique");handler.postDelayed(this,500);}});
  button(box,"Vérifier les prises",()->{RelayService.checkRequested.set(true);message("Contrôle demandé. Les résultats apparaîtront ici lorsque le relais sera démarré.");});
  button(box,"Mettre à jour une clé locale",()->{
   if(RelayService.running){message("Arrêtez le relais avec le bouton Arrêter avant de modifier une clé.");return;}
   LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(32,16,32,16);
   EditText poste=new EditText(this);poste.setHint("Numéro du poste");poste.setInputType(2);form.addView(poste);
   EditText key=new EditText(this);key.setHint("Nouvelle local_key");key.setInputType(129);form.addView(key);
   new AlertDialog.Builder(this).setTitle("Clé locale de la prise").setView(form).setNegativeButton("Annuler",null).setPositiveButton("Enregistrer",(dialog,w)->{
    try{int n=Integer.parseInt(poste.getText().toString());String value=key.getText().toString();if(n<1||value.getBytes("UTF-8").length!=16)throw new Exception();
     JSONObject config=new JSONObject(Vault.load(this));JSONObject postes=config.getJSONObject("postes");String did=postes.getString(String.valueOf(n));config.getJSONObject("devices").getJSONObject(did).put("key",value);Vault.save(this,config.toString());key.setText("");message("Clé enregistrée. Démarrez le relais puis vérifiez les prises.");
    }catch(Exception e){message("Clé refusée : importer la configuration, puis saisir un poste configuré et une clé de 16 octets.");}
   }).show();
  });
  button(box,"Importer la configuration locale",()->{
   if(RelayService.running){message("Arrêtez le relais avant un nouvel import.");return;}
   Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("application/zip").addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,41);
  });
  button(box,"Démarrer le relais",()->{
   if(!new File(getFilesDir(),"config.enc").exists()){message("Importez la configuration d’abord.");return;}
   if(Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},9);return;}
   getSharedPreferences("relay",0).edit().putBoolean("enabled",true).apply();
   try{startForegroundService(new Intent(this,RelayService.class));}catch(RuntimeException e){message("Android refuse le démarrage. Vérifiez les autorisations de l’application.");}
  });
  button(box,"Autoriser le fonctionnement continu",()->{
   Intent i=new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,Uri.parse("package:"+getPackageName()));
   try{startActivity(i);}catch(RuntimeException e){startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())));}
  });
  button(box,"Voir le diagnostic",()->{
   try {
    java.util.List<String> lines=java.nio.file.Files.readAllLines(new File(getFilesDir(),"diagnostic.log").toPath());
    message(String.join("\n",lines.subList(Math.max(0,lines.size()-40),lines.size())));
   }catch(Exception e){message("Aucun événement enregistré pour le moment.");}
  });
  button(box,"Arrêter le relais",()->new AlertDialog.Builder(this).setMessage("Arrêter les nouvelles commandes ? Les minuteurs des prises déjà programmés continuent. Le redémarrage automatique sera désactivé.").setNegativeButton("Annuler",null).setPositiveButton("Arrêter",(d,w)->{
   getSharedPreferences("relay",0).edit().putBoolean("enabled",false).apply();stopService(new Intent(this,RelayService.class));RelayService.status="Arrêt demandé";
  }).show());
  handler.post(new Runnable(){public void run(){
   String configured=new File(getFilesDir(),"config.enc").exists()?"Configuration importée":"Configuration manquante";
   long age=RelayService.progress==0?0:(SystemClock.elapsedRealtime()-RelayService.progress)/1000;
   devices.setText(RelayService.devicesText);
   state.setText(configured+"\n"+RelayService.status+(RelayService.running?"\nDernière progression : "+age+" s":""));handler.postDelayed(this,1000);
  }});
 }
 @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);super.onDestroy();}
 @Override protected void onActivityResult(int request,int result,Intent data){
  super.onActivityResult(request,result,data);
  if(request==42){
   if(result==RESULT_OK&&data!=null&&data.getData()!=null){
    Uri uri=data.getData();
    try{
     getContentResolver().takePersistableUriPermission(uri,data.getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION);
     getSharedPreferences("music",0).edit().putString("uri",uri.toString()).apply();
     startForegroundService(new Intent(this,MusicService.class).setAction(MusicService.PLAY).setData(uri));
    }catch(RuntimeException e){message("Son inaccessible. Choisissez un fichier audio enregistré sur ce téléphone.");}
   }
   return;
  }
  if(request!=41||result!=RESULT_OK||data==null)return;
  try {
   String config=null,deadlines="{}";int total=0;boolean foundDeadlines=false;
   try(ZipInputStream zip=new ZipInputStream(getContentResolver().openInputStream(data.getData()))){
    ZipEntry e;while((e=zip.getNextEntry())!=null){
     if(e.isDirectory() || (!e.getName().equals("prive.json")&&!e.getName().equals("echeances.json")))throw new IOException();
     ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[4096];int n;
     while((n=zip.read(buf))!=-1){total+=n;if(total>1048576)throw new IOException();out.write(buf,0,n);}
     String text=out.toString("UTF-8");if(e.getName().equals("prive.json")) {if(config!=null)throw new IOException();config=text;}else {if(foundDeadlines)throw new IOException();foundDeadlines=true;deadlines=text;}
    }
   }
   if(config==null)throw new IOException();
   if(RelayService.running || getSharedPreferences("relay",0).getBoolean("enabled",false)) {
    message("Arrêtez le relais avant de mettre à jour la configuration.");return;
   }
   if(!Python.isStarted())Python.start(new AndroidPlatform(this));
   String clean=Python.getInstance().getModule("engine").callAttr("validate_import",config,deadlines).toString();
   // Update local addresses and keys; keep Firebase credentials and runtime files.
   if(new File(getFilesDir(),"config.enc").exists()) {
    String updated=Python.getInstance().getModule("engine").callAttr("merge_address_update",Vault.load(this),clean).toString();
    Vault.save(this,updated);
    RelayService.devicesText="Clés et adresses mises à jour — vérification en attente";
    message("Sept clés locales importées. Connexion Firebase, sessions et minuteurs existants conservés. Vérifiez les prises après démarrage.");
    return;
   }
   // A distinct lease identity prevents accidental simultaneous use with Termux.
   JSONObject json=new JSONObject(clean);
   String agent=getSharedPreferences("relay",0).getString("agent",null);
   if(agent==null){agent=java.util.UUID.randomUUID().toString();getSharedPreferences("relay",0).edit().putString("agent",agent).apply();}
   json.put("agent",agent);
   // Never import a configuration while an existing relay has been enabled.
   if(getSharedPreferences("relay",0).getBoolean("enabled",false))throw new IOException();
   File destination=new File(getFilesDir(),"echeances.json");
   if(destination.exists())throw new IOException(); // Never overwrite live deadlines on reimport.
   File tmp=new File(getFilesDir(),"echeances.tmp");
   try(FileOutputStream out=new FileOutputStream(tmp)){out.write(deadlines.getBytes(java.nio.charset.StandardCharsets.UTF_8));out.getFD().sync();}
   Vault.save(this,json.toString());
   java.nio.file.Files.move(tmp.toPath(),destination.toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING);
   message("Prises importées. Clés conservées dans le stockage privé chiffré. Après arrêt de Termux, attendez 60 secondes avant de démarrer ce relais.");
  }catch(Exception e){message("Import refusé. Vérifiez le ZIP, la salle et les postes. Aucun secret n’est affiché.");}
 }
}


